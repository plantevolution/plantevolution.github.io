#
# Script to replicate the analyses of the paper:
#
# Joly et al. - Greater pollination generalization is not associated with 
#                 reduced constraints on corolla shape in Antillean plants
#
# This script was executed with R version 3.3.2
#

# Set working directory - you will have to change this

setwd("~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir")

# Read landmark data -----------------------------------------

# This section has to be done only once. Once done, you can proceed
# to the main script.

library(geomorph)

# Open function read.nts.R
source("utility_functions.R")

# Open .nts file
rawland <- read.nts("landmark_data.nts")

# Save landmarks in R format
save(rawland,file="landmark_data.Rdata")
rm(list = ls())


# Procrustes analysis  --------------------------------------------------

library(geomorph)
library(shapes)
source("utility_functions.R")

# Open landmark data
load("landmark_data.Rdata")

## Landmarks numbers (NOT RUN)
# test<-rawland$landmarks[,,286]
# rownames(test)<-seq(from=1,by=1,length=nrow(test))
# plot(test,type='n');text(test,rownames(test))
# rm(test)

# loading data info and merge into a data.frame
names <- read.table("names.txt", header=TRUE)
dbase <- read.csv("species.csv", sep=";", header=TRUE)
dbase <- dbase[,-c(6:8)]
data <- merge(x=names, y=dbase, by.x="CodeSpecies",
              by.y="CodeSpecies",all.x=TRUE,sort=FALSE) 
data <- data[match(names[,'FileName'],data[,'FileName']),]
rm(dbase)


# Variance analysis of replicated pictures ------------

# Procrustes analysis

# Import the matrix of semi-landmarks
semi<-as.matrix(read.csv2("matrix_semilandmarks.csv",header=TRUE))

# Procrustes analysis (for semi-landmarks)
res.gpa <- gpagen(rawland$landmarks,curves=semi,ProcD=TRUE)

# Procrustes ANOVA

# Convert coordinates to 2D matrix
xx<-two.d.array(res.gpa$coords)
rownames(xx) <- rep(data[,'FileName'],each=2)

# Keep only duplicated pictures for ANOVA
data.subset <- xx[273:296,]

# Variables
flower <- rep(c(1,1,2,2,3,3),times=4)
spe.anova <- factor(rep(data[137:148,'Species'],each=2))

# Hierachical ANOVA
res <- procD.lm(data.subset~spe.anova/flower,iter=99)
(result <- data.frame(variables=c("species","species:flower","residuals","total"),
                     Sum_of_Squares=res$SS,Percent_Variance=round(res$SS/max(res$SS)*100,digits=2)))
# Results
# 98.79 % of the variation between species
#  0.23 % of the variation between picture replicates
#  0.99 % of variation between technical replicates of the same picture.

rm(result,res,spe.anova,flower,data.subset,xx,res.gpa)


# Final Procrustes analysis -------------

# Remove duplicated flowers
landmarks <- rawland$landmarks[,,-c(273:296)]
data <- data[-c(137:148),]

# Procrustes analysis (for semi-landmarks)
res.gpa <- gpagen(landmarks,curves=semi,ProcD=TRUE)
rm(semi)

## Error checking (NOT RUN) -------------------
#
## Look for large distances between replicates of the same flowers
# 
# xx<-two.d.array(res.gpa$coords)
# rownames(xx) <- rep(data[,'FileName'],each=2)
# dist.copy <- numeric(length(data[,'FileName']))
# names(dist.copy) <- data[,'FileName']
# for (i in 1:length(dist.copy)) {
#   dist.copy[i] <- dist(xx[rownames(xx)==names(dist.copy)[i],])
# }
# hist(dist.copy,breaks=40,
#      main="Distances between technical replicates\nof the same picture",
#      xlab="Euclidean distance")
# dist.copy[dist.copy>0.06]
# names(dist.copy[dist.copy>0.08])
# rm(dist.copy)
#
#
## Look for large distances between individuals within species
# 
# species <- unique(data[,'CodeSpecies'])
# xx<-two.d.array(copy)
# rownames(xx) <- rep(data[,'FileName'])
# spe.names <- data[,'CodeSpecies']
# mean.dist.spe <- numeric(length(species))
# max.dist.spe <- numeric(length(species))
# names(mean.dist.spe) <- names(max.dist.spe) <- species
# for (i in 1:length(species)) {
#   if(length(xx[spe.names==species[i],1])==1) {
#     mean.dist.spe[i] <- NA
#     max.dist.spe[i] <- NA
#   }
#   else {
#     mean.dist.spe[i] <- mean(dist(xx[spe.names==species[i],]))
#     max.dist.spe[i] <- max(dist(xx[spe.names==species[i],]))    
#   }
# }
# hist(mean.dist.spe)
# hist(max.dist.spe)
# max.dist.spe[max.dist.spe>0.25]
# mean.dist.spe[mean.dist.spe>0.25]
# 
## test specific species
# a.species="GES_viridiflora"
# dist(xx[spe.names==a.species,])
# 
## END (NOT RUN)

# Procrustes ANOVA to quantify variation among technical replicates ------

gdf <- geomorph.data.frame(shape = res.gpa$coords, ind = rep(data[,'FileName'],each=2)) # geomorph data frame
res <- procD.lm(shape ~ ind, data=gdf,iter=99)
(result <- data.frame(variables=c("individuals","residuals","total"),
                      Sum_of_Squares=res$SS,Percent_Variance=round(res$SS/max(res$SS)*100,digits=2)))
# Results:
# 0.64% of variation between copies within specimens after 
#      solving problematic specimens
rm(res,result,gdf)


# Combine the two copies per individual ------------

copy <- res.gpa$coords[,,1:(dim(res.gpa$coords)[3]/2)]
for(i in 1:dim(copy)[3]) copy[,,i] <- (res.gpa$coords[,,i*2-1]+res.gpa$coords[,,i*2])/2


# Procrustes ANOVA ------------------------------------------

xx<-two.d.array(copy)

#
# Estimate sums of squares for mixed-pollination, hummingbird, 
# and bat syndromes

# hummingbird specialists
species.hum <- as.vector(data[data[,'Pollinator']=="hummingbird",'CodeSpecies'])
names(species.hum) <- data[data[,'Pollinator']=="hummingbird",'FileName']
xx.hum<-xx[data[,'Pollinator']=="hummingbird",]
rownames(xx.hum) <- data[data[,'Pollinator']=="hummingbird",'FileName']
(hum.res <- procD.lm(xx.hum~species.hum,iter=99))
data.frame(variables=c("species","residuals","total"),
                      Sum_of_Squares=hum.res$SS,Percent_Variance=round(hum.res$SS/max(hum.res$SS)*100,digits=2))
# 80.43 % among species

# Morphological integration
hum.pca<-prcomp(xx.hum,center=T,scale=F)
var((hum.pca$sdev^2)/sum(hum.pca$sdev^2))
# 0.00306

#
# Mixed-pollination species
species.gen <- as.vector(data[data[,'Pollinator']=="mixed-pollination",'CodeSpecies'])
names(species.gen) <- data[data[,'Pollinator']=="mixed-pollination",'FileName']
xx.gen<-xx[data[,'Pollinator']=="mixed-pollination",]
rownames(xx.gen) <- data[data[,'Pollinator']=="mixed-pollination",'FileName']
(gen.res <- procD.lm(xx.gen~species.gen,iter=999))
data.frame(variables=c("species","residuals","total"),
           Sum_of_Squares=gen.res$SS,Percent_Variance=round(gen.res$SS/max(gen.res$SS)*100,digits=2))
# 61.63 % among species

# Morphological integration
gen.pca<-prcomp(xx.gen,center=T,scale=F)
var((gen.pca$sdev^2)/sum(gen.pca$sdev^2))
# 0.00354

#
# bat specialists
species.bat <- as.vector(data[data[,'Pollinator']=="bat",'CodeSpecies'])
names(species.bat) <- data[data[,'Pollinator']=="bat",'FileName']
xx.bat<-xx[data[,'Pollinator']=="bat",]
rownames(xx.bat) <- data[data[,'Pollinator']=="bat",'FileName']
(bat.res <- procD.lm(xx.bat~species.bat,iter=99))
data.frame(variables=c("species","residuals","total"),
           Sum_of_Squares=bat.res$SS,Percent_Variance=round(bat.res$SS/max(bat.res$SS)*100,digits=2))
# 83.47 % among species

# Morphological integration
bat.pca<-prcomp(xx.bat,center=T,scale=F)
var((bat.pca$sdev^2)/sum(bat.pca$sdev^2))
# 0.02318

rm(xx,species.bat,xx.bat,species.gen,xx.gen,species.hum,xx.hum,
   hum.res,gen.res,bat.res)


# Principal Component Analysis ---------------------------------------------

# PCA on individual coordinates
copy.mat<-two.d.array(copy)
res.pca<-prcomp(copy.mat,center=T,scale=F)
summary(res.pca)

# broken-stick criteria
library(vegan)
screeplot(res.pca,bstick = TRUE)

# Thin-plate spline transformation grids

c = 2 # scale for plotting (multiple of standard deviation)
meanshape <- matrix(res.pca$center,ncol=2,byrow=TRUE)
pc1min <- matrix(res.pca$center-(c*res.pca$sdev[1])*res.pca$rotation[,1],ncol=2,byrow=T)
pc1max <- matrix(res.pca$center+(c*res.pca$sdev[1])*res.pca$rotation[,1],ncol=2,byrow=T)
pc2min <- matrix(res.pca$center-(c*res.pca$sdev[2])*res.pca$rotation[,2],ncol=2,byrow=T)
pc2max <- matrix(res.pca$center+(c*res.pca$sdev[2])*res.pca$rotation[,2],ncol=2,byrow=T)
op <- par(mfrow=c(2,2),mar=c(0,0,0,0))
tps1(meanshape, pc1min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc1max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc2min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc2max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
par(op)


# Calculate mean PC coordinates per species
species <- unique(data[,'CodeSpecies'])
res.tan.spe<-matrix(data=NA,nrow=length(species),ncol=2)
for (i in 1:length(species)){
  if(length(data[data[,'CodeSpecies']==species[i],1])==1) {
    res.tan.spe[i,]<-res.pca$x[data[,'CodeSpecies']==species[i],1:2]
  }
  else 
    res.tan.spe[i,]<-apply(res.pca$x[data[,'CodeSpecies']==species[i],1:2],2,mean)
}
rownames(res.tan.spe) <- species

rm(copy.mat,c,meanshape,pc1min,pc1max,pc2min,pc2max)


# PCA figures for the paper ---------------------------------------------------

# Create table to draw lines
tab.lines<-matrix(nrow=nrow(res.pca$x),ncol=2)
for(i in 1:nrow(res.pca$x)) {
  tab.lines[i,]<-res.tan.spe[species==data[i,"CodeSpecies"]]
}

# Get pollinator information
pol<-as.vector(data[!duplicated(data[,'CodeSpecies']),'Pollinator'])
pol[data[!duplicated(data[,'CodeSpecies']),'Confirmed']=="no"] <- "unknown"
pol <- as.factor(pol)
spe.names<-data[!duplicated(data[,'CodeSpecies']),'CodeSpecies']

# With ggplot2
require(ggplot2)

# Data for lines - ggplot
all.pol <- as.vector(data[,'Pollinator'])
all.pol[data[,'Confirmed']=="no"] <- "unknown"
all.pol <- as.factor(all.pol)
amatrix <- data.frame(PC1=numeric(),PC2=numeric(),pollinator=factor(character(),levels=c("bat","hummingbird","mixed-pollination","unknown")),species=numeric())
for (i in 1:nrow(res.pca$x)) {
  amatrix <- rbind(amatrix,
                   data.frame(PC1=tab.lines[i,1],PC2=tab.lines[i,2],pollinator=all.pol[i],species=i),
                   data.frame(PC1=res.pca$x[i,1],PC2=res.pca$x[i,2],pollinator=all.pol[i],species=i))
}
tab.lines.ggplot <- amatrix


# data.frames
data1 <- data.frame(species=spe.names,PC1=res.tan.spe[,1],
                            PC2=res.tan.spe[,2],pollinator=pol,
                            type="species", size=2)
data2 <- data.frame(species=data[,'FileName'],
                            PC1=res.pca$x[,1],PC2=res.pca$x[,2],
                            pollinator=all.pol,
                            type="individual", size=0.5)

pdf("PCA_ggplot.pdf",height=5,width=8)
op <- par(mar=c(3.5,3.5,1,1),mgp=c(1.5,0.5,0),tcl=0.3)
p <- ggplot(tab.lines.ggplot, aes(x=PC1,y=PC2,colour=pollinator,group=species)) + 
  geom_path(size=0.5,alpha=0.8) + 
  geom_point(data=data2, aes(x=PC1,y=PC2,colour=pollinator), size=2, alpha=0.9) + 
  geom_point(data=data1, aes(x=PC1,y=PC2,colour=pollinator), size=6, alpha=0.75) + 
  theme_minimal() + labs(colour = "Pollination syndrome") + 
  lims(x = c(-0.45, 0.5), y = c(-0.65, 0.4)) +
  xlab(paste0("PC1 (",round(summary(res.pca)$importance[2,1]*100,1),"% of the variance)")) +
  ylab(paste0("PC2 (",round(summary(res.pca)$importance[2,2]*100,1),"% of the variance)")) +
  theme(legend.justification=c(1,0), legend.position=c(1,0), legend.background = element_rect(fill="gray95",colour=NA)) + 
  scale_colour_manual(values = c("#1b9e77","#d95f02","#7570b3","#e78ac3","gray"))
p
par(op)
dev.off()

# Supplementary figure
require(plotly)
new.tab.lines <- tab.lines.ggplot[0,]
for (i in 1:(nrow(tab.lines.ggplot)/2)) {
  new.tab.lines <- rbind(new.tab.lines,tab.lines.ggplot[c(i*2-1,i*2),],NA)
}
data1$pollinator <- factor(as.vector(data1$pollinator))
data2$pollinator <- factor(as.vector(data2$pollinator))

cols <- c("#1b9e77","#d95f02","#7570b3","#e78ac3","gray")

p <- plot_ly() %>%
  add_trace(type = "scatter", mode = "lines",
            x = new.tab.lines$PC1, y = new.tab.lines$PC2, showlegend=FALSE, hoverinfo = "none",
            line = list(color="gray",width=1)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = data2$PC1, y = data2$PC2, hoverinfo= "text",
            text = data2$species, showlegend=FALSE,
            marker = list(color = cols[data2$pollinator], opacity=0.7,size=8)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = data1[data1$pollinator=="bat",]$PC1,
            y = data1[data1$pollinator=="bat",]$PC2,
            text = data1[data1$pollinator=="bat",]$species,
            showlegend=TRUE, name="bat",hoverinfo= "text",
            marker = list(color = "#1b9e77",opacity=0.7,size=18)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = data1[data1$pollinator=="hummingbird",]$PC1,
            y = data1[data1$pollinator=="hummingbird",]$PC2,
            text = data1[data1$pollinator=="hummingbird",]$species,
            showlegend=TRUE, name="hummingbird",hoverinfo= "text",
            marker = list(color = "#d95f02",opacity=0.7,size=18)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = data1[data1$pollinator=="mixed-pollination",]$PC1,
            y = data1[data1$pollinator=="mixed-pollination",]$PC2,
            text = data1[data1$pollinator=="mixed-pollination",]$species,
            showlegend=TRUE, name="mixed-pollination",hoverinfo= "text",
            marker = list(color = "#7570b3",opacity=0.7,size=18)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = data1[data1$pollinator=="moth",]$PC1,
            y = data1[data1$pollinator=="moth",]$PC2,
            text = data1[data1$pollinator=="moth",]$species,
            showlegend=TRUE, name="moth",hoverinfo= "text",
            marker = list(color = "#e78ac3",opacity=0.7,size=18)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = data1[data1$pollinator=="unknown",]$PC1,
            y = data1[data1$pollinator=="unknown",]$PC2,
            text = data1[data1$pollinator=="unknown",]$species,
            showlegend=TRUE, name="unknown",hoverinfo= "text",
            marker = list(color = "gray",opacity=0.7,size=18)) %>%
  layout(hovermode="closest")
p


# PCA on mixed-pollination and bat specialists ----------------------------------

# This analysis is mentionned as "data not shown" in the paper

copy.mat<-two.d.array(copy)
genbat.pca<-prcomp(copy.mat[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),],
                   center=T,scale=F)
summary(genbat.pca)

# Thin-plate spline transformation grids

c = 2 # scale for plotting (multiple of standard deviation)
meanshape <- matrix(genbat.pca$center,ncol=2,byrow=TRUE)
pc1min <- matrix(genbat.pca$center-(c*genbat.pca$sdev[1])*genbat.pca$rotation[,1],ncol=2,byrow=T)
pc1max <- matrix(genbat.pca$center+(c*genbat.pca$sdev[1])*genbat.pca$rotation[,1],ncol=2,byrow=T)
pc2min <- matrix(genbat.pca$center-(c*genbat.pca$sdev[2])*genbat.pca$rotation[,2],ncol=2,byrow=T)
pc2max <- matrix(genbat.pca$center+(c*genbat.pca$sdev[2])*genbat.pca$rotation[,2],ncol=2,byrow=T)
pc3min <- matrix(genbat.pca$center-(c*genbat.pca$sdev[3])*genbat.pca$rotation[,3],ncol=2,byrow=T)
pc3max <- matrix(genbat.pca$center+(c*genbat.pca$sdev[3])*genbat.pca$rotation[,3],ncol=2,byrow=T)
op <- par(mfrow=c(3,2),mar=c(0,0,0,0))
tps1(meanshape, pc1min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc1max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc2min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc2max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc3min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc3max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
par(op)

# Plot PCA

# Calculate mean PC coordinates per species
genbat.species <- unique(data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'CodeSpecies'])
mean.genbat.tan<-matrix(data=NA,nrow=length(genbat.species),ncol=3)
for (i in 1:length(genbat.species)){
  if(length(data[data[,'CodeSpecies']==genbat.species[i],1])==1) {
    mean.genbat.tan[i,]<-genbat.pca$x[data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'CodeSpecies']==genbat.species[i],c(1:3)]
  }
  else 
    mean.genbat.tan[i,]<-apply(genbat.pca$x[data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'CodeSpecies']==genbat.species[i],1:3],2,mean)
}
rownames(mean.genbat.tan) <- genbat.species

# Get pollinator info for species means
mean.genbat.pol <- as.vector(data[match(genbat.species,data$CodeSpecies),'Pollinator'])
mean.genbat.pol[data[match(genbat.species,data$CodeSpecies),'Confirmed']=="no"] <- "unknown"
mean.genbat.pol <- factor(mean.genbat.pol)
genbat.pol <- as.vector(data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'Pollinator'])
genbat.pol[data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'Confirmed']=="no"] <- "unknown"
genbat.pol <- factor(genbat.pol)

# Create table to draw lines
genbat.tab.lines<-matrix(nrow=nrow(genbat.pca$x),ncol=3)
for(i in 1:nrow(genbat.pca$x)) {
  genbat.tab.lines[i,]<-mean.genbat.tan[genbat.species==data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),"CodeSpecies"][i]]
}

# plot with ggplot2
require(ggplot2)
gen.bat.data1 <- data.frame(species=genbat.species,PC1=mean.genbat.tan[,1],PC2=mean.genbat.tan[,2],
                            PC3=mean.genbat.tan[,3],pollinator=mean.genbat.pol,
                            type="species", size=2)
gen.bat.data2 <- data.frame(species=data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'FileName'],
                            PC1=genbat.pca$x[,1],PC2=genbat.pca$x[,2],PC3=genbat.pca$x[,3],
                            pollinator=genbat.pol,
                            type="individual", size=0.5)
# Data for lines - ggplot
amatrix <- data.frame(PC1=numeric(),PC2=numeric(),PC3=numeric(),pollinator=factor(character(),levels=c("bat","mixed-pollination","unknown")),species=numeric())
for (i in 1:nrow(genbat.pca$x)) {
  amatrix <- rbind(amatrix,
                   data.frame(PC1=genbat.tab.lines[i,1],PC2=genbat.tab.lines[i,2],PC3=genbat.tab.lines[i,3],pollinator=genbat.pol[i],species=i),
                   data.frame(PC1=genbat.pca$x[i,1],PC2=genbat.pca$x[i,2],PC3=genbat.pca$x[i,3],pollinator=genbat.pol[i],species=i))
}
gen.bat.data.lines.ggplot <- amatrix

pdf("PCA_no_hummingbirds_ggplot.pdf",height=5,width=8)
op <- par(mar=c(3.5,3.5,1,1),mgp=c(1.5,0.5,0),tcl=0.3)
p <- ggplot(gen.bat.data.lines.ggplot, aes(x=PC2,y=-PC3,colour=as.factor(pollinator),group=species)) + 
  geom_path(size=0.5,alpha=0.8) + 
  geom_point(data=gen.bat.data2, aes(x=PC2,y=-PC3,colour=pollinator), size=2,alpha=0.9) + 
  geom_point(data=gen.bat.data1, aes(x=PC2,y=-PC3,colour=pollinator), size=6,alpha=0.75) + 
  theme_minimal() + labs(colour = "Pollination syndrome") + 
  lims(x = c(-0.25, 0.35), y = c(-0.22, 0.3)) +
  xlab(paste0("PC2 (",round(summary(genbat.pca)$importance[2,2]*100,1),"% of the variance)")) +
  ylab(paste0("PC3 (",round(summary(genbat.pca)$importance[2,3]*100,1),"% of the variance)")) +
  theme(legend.justification=c(1,0), legend.position=c(1,0), legend.background = element_rect(fill="gray95",colour=NA)) + 
  scale_colour_manual(values = c("#1b9e77","#7570b3","gray"))
p
par(op)
dev.off()

# supplemetary figure -----
library(plotly)
amatrix <- matrix(NA,ncol=2,nrow=0)
for (i in 1:nrow(genbat.pca$x)) {
  amatrix <- rbind(amatrix,genbat.tab.lines[i,c(2,3)],genbat.pca$x[i,c(2,3)],c(NA,NA))  
}
gen.bat.data.lines <- data.frame(PC2=amatrix[,1],PC3=amatrix[,2])

genbat.cols <- c("#1b9e77","#7570b3","gray")

p <- plot_ly() %>%
  add_trace(type = "scatter", mode = "lines",
            x = gen.bat.data.lines$PC2, y = -gen.bat.data.lines$PC3, showlegend=FALSE, hoverinfo = "none",
            line = list(color="gray",width=1)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = gen.bat.data2$PC2, y = -gen.bat.data2$PC3, hoverinfo= "text",
            text = gen.bat.data2$species, showlegend=FALSE,
            marker = list(color = genbat.cols[gen.bat.data2$pollinator], opacity=0.7,size=8)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = gen.bat.data1[gen.bat.data1$pollinator=="bat",]$PC2,
            y = -gen.bat.data1[gen.bat.data1$pollinator=="bat",]$PC3,
            text = gen.bat.data1[gen.bat.data1$pollinator=="bat",]$species,
            showlegend=TRUE, name="bat",hoverinfo= "text",
            marker = list(color = "#1b9e77",opacity=0.7,size=18)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = gen.bat.data1[gen.bat.data1$pollinator=="mixed-pollination",]$PC2,
            y = -gen.bat.data1[gen.bat.data1$pollinator=="mixed-pollination",]$PC3,
            text = gen.bat.data1[gen.bat.data1$pollinator=="mixed-pollination",]$species,
            showlegend=TRUE, name="mixed-pollination",hoverinfo= "text",
            marker = list(color = "#7570b3",opacity=0.7,size=18)) %>%
  add_trace(type = "scatter", mode = "markers",
            x = gen.bat.data1[gen.bat.data1$pollinator=="unknown",]$PC2,
            y = -gen.bat.data1[gen.bat.data1$pollinator=="unknown",]$PC3,
            text = gen.bat.data1[gen.bat.data1$pollinator=="unknown",]$species,
            showlegend=TRUE, name="unknown",hoverinfo= "text",
            marker = list(color = "gray",opacity=0.7,size=18)) %>%
  layout(hovermode="closest",
         xaxis=list(title="PC2"),
         yaxis=list(title="PC3"))
p

save(list=c("gen.bat.data.lines","gen.bat.data1","gen.bat.data2",
            "new.tab.lines","data1","data2"),
      file="data_supp_figs.RData")

rm(copy.mat,genbat.pca,c,meanshape,pc1min,pc1max,pc2min,pc2max,pc3min,pc3max,genbat.pol)


# Ancestral state reconstruction (MCC tree) - model selection ----------

#Read syndrome data
syndata <- read.csv("species.csv", sep=";", header=TRUE)
syndata <- syndata[,c(1,4:5)]
rownames(syndata) <- syndata[,'CodeSpecies']

#Open tree
spe.tree <- read.nexus("BestTree.tre")

#Change species names to fit that of the table
spe.tree$tip.label <- sub("G","GES_",spe.tree$tip.label)
spe.tree$tip.label <- sub("R","RHY_",spe.tree$tip.label)
spe.tree$tip.label <- sub("B","BEL_",spe.tree$tip.label)

#Remove species for which we don't have data
exclude.nodata <- unique(as.vector(syndata[!(as.vector(syndata[,"CodeSpecies"]) %in% spe.tree$tip.label),"CodeSpecies"]))
exclude.nodata2 <- spe.tree$tip.label[!(spe.tree$tip.label %in% as.vector(syndata[,"CodeSpecies"]))]
exclude <- unique(c(exclude.nodata,exclude.nodata2))
spe.tree <- drop.tip(spe.tree,exclude)

# Remove species for which pollination modes are unknown
exclude.nodata3 <- spe.tree$tip.label[!(spe.tree$tip.label %in% syndata[syndata[,"Pollinator"]!="unknown","CodeSpecies"])]
spe.tree <- drop.tip(spe.tree,exclude.nodata3)

#Reorder data frame
syndata <- syndata[match(spe.tree$tip.label,rownames(syndata)),]

#Vector of pollinator data
pollinator.data <- as.factor(as.vector(syndata$Pollinator))
names(pollinator.data) <- syndata[,'CodeSpecies']

#Test different evolutionary models
library(geiger)
results.anc <- data.frame(model=c("ER","ER.2","SYM","SYM.2","ARD","ARD.2","from.to","hum.2.other"),
                          lnL=numeric(8),AICc=numeric(8),params=numeric(8))
char1 <- as.vector(pollinator.data)
names(char1) <- spe.tree$tip.label
# ER
(pol_anc <- fitDiscrete(spe.tree,char1,model="ER"))
results.anc[1,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# ER.2
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 2, 2, 1,  1, 0, 1, 1, 1, 
                                       2, 1, 0, 2, 1, 
                                       2, 1, 2, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[2,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# SYM
(pol_anc <- fitDiscrete(spe.tree,char1,model="SYM"))
results.anc[3,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# SYM.2
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 2, 3, 1,  1, 0, 1, 1, 1, 
                                       2, 1, 0, 4, 1, 
                                       3, 1, 4, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[4,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# ARD
(pol_anc <- fitDiscrete(spe.tree,char1,model="ARD"))
results.anc[5,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# ARD.2
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 2, 3, 1,  1, 0, 1, 1, 1, 
                                       4, 1, 0, 5, 1, 
                                       6, 1, 7, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[6,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# from.to
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 3, 4, 1,  1, 0, 1, 1, 1, 
                                       2, 1, 0, 4, 1, 
                                       2, 1, 3, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[7,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# hum.2.other
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 2, 3, 1,  1, 0, 1, 1, 1, 
                                       3, 1, 0, 3, 1, 
                                       3, 1, 2, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[8,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# Order results by AICc
results.anc[order(results.anc$AICc),]
# Best model: hum.2.others


# Get mean shapes per species for phylogeny ----

require(ape)
spe.tree <- read.nexus("BestTree.tre")

#Change species names to fit that of the table
spe.tree$tip.label <- sub("G","GES_",spe.tree$tip.label)
spe.tree$tip.label <- sub("R","RHY_",spe.tree$tip.label)

#Remove species for which we don't have data
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% spe.tree$tip.label),"CodeSpecies"]))
exclude.nodata2 <- spe.tree$tip.label[!(spe.tree$tip.label %in% as.vector(data[,"CodeSpecies"]))]
exclude <- unique(c(exclude.nodata,exclude.nodata2))
spe.tree <- drop.tip(spe.tree,exclude)

# Order data according to tree tips
# Calculate mean PC coordinates per species
species <- unique(data[,'CodeSpecies'])
res.tan.spe<-matrix(data=NA,nrow=length(species),ncol=64)
for (i in 1:length(species)){
  if(length(data[data[,'CodeSpecies']==species[i],1])==1) {
    res.tan.spe[i,]<-res.pca$x[data[,'CodeSpecies']==species[i],]
  }
  else 
    res.tan.spe[i,]<-apply(res.pca$x[data[,'CodeSpecies']==species[i],],2,mean)
}
rownames(res.tan.spe) <- species
res.tan.spe <- res.tan.spe[match(spe.tree$tip.label,rownames(res.tan.spe)),]

# Vector of pollinator data
pollinator.data <- data[match(rownames(res.tan.spe),data[,'CodeSpecies']),'Pollinator']
pollinator.data <- as.factor(as.vector(pollinator.data))

# Get mean corolla shapes per species
species.shapes <- matrix(nrow=nrow(res.tan.spe),ncol=64)
rownames(species.shapes) <- rownames(res.tan.spe)
for (i in 1:nrow(res.tan.spe)){
  species.shapes[i,] <- res.pca$center + 
    apply(sweep(res.pca$rotation[,],MARGIN=2,res.tan.spe[i,],'*'),MARGIN=1,sum)
}

# Plot mean corolla chapes per species
pdf("shapes_nonames.pdf",height=30,width=3)
op<-par(mar=c(0,0,0,0),mfrow=c(nrow(species.shapes),1),mgp=c(-0.5,0,0))
for (i in 1:nrow(species.shapes)) {
  plot(matrix(species.shapes[i,],ncol=2,byrow=T),axes=F,
       xlab="",
       ylab="",pch=21,bg="black",cex=0.7,
       xlim=c(-0.4,0.4),ylim=c(-0.4,0.4),asp=1)
}
par(op)
dev.off()

pdf("shapes_withnames.pdf",height=35,width=3)
op<-par(mar=c(0,0,0,0),mfrow=c(nrow(species.shapes),1),mgp=c(-1,0,0))
for (i in 1:nrow(species.shapes)) {
  plot(matrix(species.shapes[i,],ncol=2,byrow=T),axes=F,
       xlab=rownames(species.shapes)[i],
       ylab="",pch=21,bg="black",cex=0.6,
       xlim=c(-0.4,0.4),ylim=c(-0.4,0.4),asp=1)
}
par(op)
dev.off()


# Ancestral state reconstruction (MCC tree) ----------

library(phytools)

#Read syndrome data
syndata <- read.csv("species.csv", sep=";", header=TRUE)
syndata <- syndata[,c(1,4:5)]
rownames(syndata) <- syndata[,'CodeSpecies']

#Open tree
spe.tree <- read.nexus("BestTree.tre")

#Change species names to fit that of the table
spe.tree$tip.label <- sub("G","GES_",spe.tree$tip.label)
spe.tree$tip.label <- sub("R","RHY_",spe.tree$tip.label)
spe.tree$tip.label <- sub("B","BEL_",spe.tree$tip.label)

#Remove species for which we don't have data
exclude.nodata <- unique(as.vector(syndata[!(as.vector(syndata[,"CodeSpecies"]) %in% spe.tree$tip.label),"CodeSpecies"]))
exclude.nodata2 <- spe.tree$tip.label[!(spe.tree$tip.label %in% as.vector(syndata[,"CodeSpecies"]))]
exclude <- unique(c(exclude.nodata,exclude.nodata2))
spe.tree <- drop.tip(spe.tree,exclude)

# Remove species for which pollination modes are not confirmed
#exclude.nodata3 <- spe.tree$tip.label[!(spe.tree$tip.label %in% syndata[syndata[,"Confirmed"]!="no","CodeSpecies"])]
#spe.tree <- drop.tip(spe.tree,exclude.nodata3)

#Reorder data frame
syndata <- syndata[match(spe.tree$tip.label,rownames(syndata)),]

#Vector of pollinator data
pollinator.data <- as.factor(as.vector(syndata$Pollinator))
names(pollinator.data) <- syndata[,'CodeSpecies']

chartrees <- make.simmap(spe.tree, pollinator.data,
                         model=matrix(c(0, 1, 2, 3, 1, 1, 0, 1, 1, 1, 3, 1, 0, 3, 1, 3, 1, 2, 0, 1, 1, 1, 1, 1, 0), 5),
                         nsim = 1000)

# Output summary information
(res_simmap <- describe.simmap(chartrees, plot = FALSE))

# Plot the tree with posterior probabilities of states at each node
cols <- setNames(c("#1b9e77","goldenrod","#d95f02","#7570b3","#e78ac3"), sort(unique(pollinator.data)))
plot(spe.tree,type="p",FALSE,label.offset=0.6,cex=0.7,no.margin=TRUE,
     edge.color="gray32",tip.color="gray32")
tiplabels(pch=21,bg=cols[as.numeric(pollinator.data)],col="gray32",cex=1,adj=0.6)
nodelabels(pie=res_simmap$ace,piecol=cols,cex=0.5,col="gray32")
legend("bottomleft",legend=levels(pollinator.data),
       pch=20,col=cols,bty="n",
       text.col="gray32",cex=0.8,pt.cex=1.5)

###
# Analysis with only confirmed syndromes:

# Assign equal prior prob. for the different syndromes 
# for undetermined species
pollinator.prior <- model.matrix(~pollinator.data)
rownames(pollinator.prior) <- names(pollinator.data)
colnames(pollinator.prior) <- levels(pollinator.data)
pollinator.prior[,1] <- 0
for (row in 1:nrow(pollinator.prior)) if (sum(pollinator.prior[row,])==0) pollinator.prior[row,1]<-1
undetermined <- spe.tree$tip.label[!(spe.tree$tip.label %in% syndata[syndata[,"Confirmed"]!="no","CodeSpecies"])]
for (row in 1:nrow(pollinator.prior))
  if (rownames(pollinator.prior)[row] %in% undetermined)
    pollinator.prior[row,] <- rep(0.2,length.out=5)

chartrees <- make.simmap(spe.tree, pollinator.prior,
                         model=matrix(c(0, 1, 2, 3, 1, 1, 0, 1, 1, 1, 3, 1, 0, 3, 1, 3, 1, 2, 0, 1, 1, 1, 1, 1, 0), 5),
                         nsim = 2000)

# Output summary information
(res_simmap <- describe.simmap(chartrees, plot = FALSE))

# Plot the tree with posterior probabilities of states at each node
cols <- setNames(c("#1b9e77","goldenrod","#d95f02","#7570b3","#e78ac3"), sort(unique(pollinator.data)))
plot(spe.tree,type="p",FALSE,label.offset=2,cex=0.7,no.margin=TRUE,edge.color="gray32",tip.color="gray32")
tiplabels(pie=pollinator.prior,piecol=cols,col="gray32",cex=0.5,adj=1.5)
nodelabels(pie=res_simmap$ace,piecol=cols,cex=0.5,col="gray32")
legend("bottomleft",legend=levels(pollinator.data),
       pch=20,col=cols,bty="n",
       text.col="gray32",cex=0.8,pt.cex=1.5)


# ASR posterior distribution of species trees ------------

#Read syndrome data
syndata <- read.csv("species.csv", sep=";", header=TRUE)
syndata <- syndata[,c(1,4:5)]
rownames(syndata) <- syndata[,'CodeSpecies']

# Read a random sample from the tree posterior
require(ape)
#spe.trees <- read.nexus("AllTrees.trees")
#set.seed(3246)
#random.trees<-sample(spe.trees,size=5000)
#rm(spe.trees)
random.trees <- read.nexus("FiveThousandTrees.trees")

# Change species names to fit that of the table
attr(random.trees,"TipLabel") <- sub("G","GES_",random.trees$tip.label$tip.label)
attr(random.trees,"TipLabel") <- sub("R","RHY_",random.trees$tip.label$tip.label)
attr(random.trees,"TipLabel") <- sub("B","BEL_",random.trees$tip.label$tip.label)

#Remove species for which we don't have data or pollination modes are unknown
exclude.nodata <- unique(as.vector(syndata[!(as.vector(syndata[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% as.vector(syndata[,"CodeSpecies"]))]
exclude <- unique(c(exclude.nodata,exclude.nodata2))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

#Reorder data frame
syndata <- syndata[match(attr(random.trees,"TipLabel"),rownames(syndata)),]

#Vector of pollinator data
pollinator.data <- as.factor(as.vector(syndata$Pollinator))
names(pollinator.data) <- syndata[,'CodeSpecies']

# Stochastic mapping on posterior to get credible intervals

## For simulations of cluster (NOT RUN)
# save(random.trees,pollinator.data,file="stochastic_mapping.Rdata")
# load(file="stochastic_mapping.Rdata")

one.asr.sim <- function(trees,tree.nb,regimes) {
  #cat("Processing replicate",tree.nb,"\n")  
  mytree<-trees[[tree.nb]]
  # simulate single stochastic character map using empirical Bayes method
  require(phytools)
  chartrees <- make.simmap(mytree, regimes, model=matrix(c(0, 3, 1, 2, 3, 0, 3, 3, 2, 3, 0, 2, 2, 3, 1, 0), 4), 
                           Q=matrix(c(-216.1, 8.7,  34.4,   99.4,  8.7,
                                      8.7,  -34.6,    8.7,    8.7, 8.7,
                                      99.4,   8.7, -86,     99.4, 8.7,
                                      99.4,  8.7,   34.3, -216.1,  8.7,
                                      8.7,    8.7,    8.7,    8.7, -34.4), 5, dimnames=list(c("bat","bee","hummingbird","mixed-pollination","moth"),c("bat","bee","hummingbird","mixed-pollination","moth"))),
                           nsim = 201, message=F)
  res_simmap <- describe.simmap(chartrees, plot = FALSE)
  if (ncol(res_simmap$count)!=21) break #Check for errors!
  #change.matrix.table[tree.nb,] <- apply(res_simmap$count,2,mean)
  apply(res_simmap$count,2,mean)
}

# The simulations
library(parallel)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir/asr_out.txt") # Initiate cluster
replicates=50
set.seed(1234)
res.asr <- parSapply(cl,seq(1,length.out=replicates),function(c) one.asr.sim(trees=random.trees,tree.nb=c,regimes=pollinator.data))
stopCluster(cl)

apply(res.asr,1, function(c) round(quantile(c,probs=c(0.025,0.5,0.975)),2))

#For cluster analysis (NOT RUN)
#save(change.matrix.table,file="change.matrix.table")


# ASR posterior distribution of trees - confirmed syndomes ------------

# Assign equal prior prob. for the different syndromes 
# for undetermined species
pollinator.prior <- model.matrix(~pollinator.data)
rownames(pollinator.prior) <- names(pollinator.data)
colnames(pollinator.prior) <- levels(pollinator.data)
pollinator.prior[,1] <- 0
for (row in 1:nrow(pollinator.prior)) if (sum(pollinator.prior[row,])==0) pollinator.prior[row,1]<-1
undetermined <- spe.tree$tip.label[!(spe.tree$tip.label %in% syndata[syndata[,"Confirmed"]!="no","CodeSpecies"])]
for (row in 1:nrow(pollinator.prior))
  if (rownames(pollinator.prior)[row] %in% undetermined)
    pollinator.prior[row,] <- rep(0.2,length.out=5)

## For simulations of cluster (NOT RUN)
# save(random.trees,pollinator.prior,file="stochastic_mapping.Rdata")
# load(file="stochastic_mapping.Rdata")

# The simulations
library(parallel)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir/asr_out.txt") # Initiate cluster
replicates=50
set.seed(1234)
res.asr <- parSapply(cl,seq(1,length.out=replicates),function(c) one.asr.sim(trees=random.trees,tree.nb=c,regimes=pollinator.prior))
stopCluster(cl)

apply(res.asr,1, function(c) round(quantile(c,probs=c(0.025,0.5,0.975)),2))


# Beta-disper on species means -------

library(vegan)
# remove species with unkown syndromes
spe.data <- res.tan.spe[pollinator.data != "unknown",]
pol.data <- factor(as.vector(pollinator.data[pollinator.data != "unknown"]))
require(vegan)
beta.dist <- betadisper(dist(spe.data),pol.data)
beta.dist
anova(beta.dist)
plot(beta.dist)
boxplot(beta.dist,ylab="Distance to centroid")
TukeyHSD(beta.dist,which="group",conf.level=0.95)


# Univariate analysis ------

# Open trees
random.trees <- read.nexus("FiveThousandTrees.trees")

# Change species names to fit that of the table
attr(random.trees,"TipLabel") <- sub("G","GES_",random.trees$tip.label$tip.label)
attr(random.trees,"TipLabel") <- sub("R","RHY_",random.trees$tip.label$tip.label)

###
# For cluster analysis
# save(random.trees,data,res.pca,file="univar_cluster.RData")
# require(ape)
# require(phytools)
# require(mvMORPH)
# require(OUwie)
# require(parallel)
# require(ggplot2)
# load("./cluster/univar_cluster.RData")

# To filter the taxa, use one of the following blocks

# 1: Remove species for which we don't have data
# exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
# exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
# exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
# exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3))
# random.trees<-lapply(random.trees,drop.tip,tip=exclude)
# class(random.trees)<-"multiPhylo"
# attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

# 2: Use only confirmed species
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
exclude.nodata4 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Confirmed"]=="no","CodeSpecies"])]
exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3,exclude.nodata4))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

# 3: Use only confirmed species - with bats
# exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
# exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
# exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth"),"CodeSpecies"])]
# exclude.nodata4 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Confirmed"]=="no","CodeSpecies"])]
# exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3,exclude.nodata4))
# random.trees<-lapply(random.trees,drop.tip,tip=exclude)
# class(random.trees)<-"multiPhylo"
# attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label


# Order data according to tree tips
# Calculate mean PC coordinates per species
species <- unique(data[,'CodeSpecies'])
res.tan.spe<-matrix(data=NA,nrow=length(species),ncol=64)
for (i in 1:length(species)){
  if(length(data[data[,'CodeSpecies']==species[i],1])==1) {
    res.tan.spe[i,]<-res.pca$x[data[,'CodeSpecies']==species[i],]
  }
  else 
    res.tan.spe[i,]<-apply(res.pca$x[data[,'CodeSpecies']==species[i],],2,mean)
}
rownames(res.tan.spe) <- species
res.tan.spe <- res.tan.spe[match(attr(random.trees,"TipLabel"),rownames(res.tan.spe)),]
colnames(res.tan.spe) = sapply(1:ncol(res.tan.spe),function(c) paste("PC",c,sep=""))

# Vector of pollinator data
#Read syndrome data
syndata <- read.csv("species.csv", sep=";", header=TRUE)
syndata <- syndata[,c(1,4:5)]
rownames(syndata) <- syndata[,'CodeSpecies']
#Reorder data frame
syndata <- syndata[match(attr(random.trees,"TipLabel"),rownames(syndata)),]
#Vector of pollinator data
pollinator.data <- as.factor(as.vector(syndata$Pollinator))
names(pollinator.data) <- syndata[,'CodeSpecies']

#pollinator.data <- data[match(rownames(res.tan.spe),data[,'CodeSpecies']),'Pollinator']
#pollinator.data <- as.factor(as.vector(pollinator.data))
#names(pollinator.data) <- data[match(rownames(res.tan.spe),data[,'CodeSpecies']),'CodeSpecies']


###
# Calculate intraspecific standard error to include 
# as error term in model fitting

data.spe.gen <- res.tan.spe[pollinator.data == "mixed-pollination",1:3]
data.ind.gen <- res.pca$x[data$Pollinator == "mixed-pollination",1:3]
rownames(data.ind.gen) <- data$CodeSpecies[data$Pollinator == "mixed-pollination"]
sd.error.gen <- matrix(nrow=nrow(data.spe.gen),ncol=3)
rownames(sd.error.gen) <- rownames(data.spe.gen)
colnames(sd.error.gen) <- colnames(data.spe.gen)
for (i in 1:nrow(sd.error.gen)) {
  temp <- data.ind.gen[rownames(data.ind.gen) == rownames(data.spe.gen)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.gen[i,1] <- sd.error.gen[i,2] <- sd.error.gen[i,3] <- NA
    next
  }
  sd.error.gen[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.gen[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                          
  sd.error.gen[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                          
}
gen.error <- mean(sd.error.gen, na.rm=TRUE)
# Replace NAs by mean
sd.error.gen[is.na(sd.error.gen)] <- gen.error

# Hummingbird specialists
data.spe.hum <- res.tan.spe[pollinator.data == "hummingbird",1:3]
data.ind.hum <- res.pca$x[data$Pollinator == "hummingbird",1:3]
rownames(data.ind.hum) <- data$CodeSpecies[data$Pollinator == "hummingbird"]
sd.error.hum <- matrix(nrow=nrow(data.spe.hum),ncol=3)
rownames(sd.error.hum) <- rownames(data.spe.hum)
colnames(sd.error.hum) <- colnames(data.spe.hum)
for (i in 1:nrow(sd.error.hum)) {
  temp <- data.ind.hum[rownames(data.ind.hum) == rownames(data.spe.hum)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.hum[i,1] <- sd.error.hum[i,2] <- sd.error.hum[i,3] <- NA
    next
  }
  sd.error.hum[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.hum[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                           
  sd.error.hum[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                           
}
hum.error <- mean(sd.error.hum, na.rm=TRUE)
# Replace NAs by mean
sd.error.hum[is.na(sd.error.hum)] <- hum.error

# bat specialists
data.spe.bat <- res.tan.spe[pollinator.data == "bat",1:3]
data.ind.bat <- res.pca$x[data$Pollinator == "bat",1:3]
rownames(data.ind.bat) <- data$CodeSpecies[data$Pollinator == "bat"]
sd.error.bat <- matrix(nrow=nrow(data.spe.bat),ncol=3)
rownames(sd.error.bat) <- rownames(data.spe.bat)
colnames(sd.error.bat) <- colnames(data.spe.bat)
for (i in 1:nrow(sd.error.bat)) {
  temp <- data.ind.bat[rownames(data.ind.bat) == rownames(data.spe.bat)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.bat[i,1] <- sd.error.bat[i,2] <- sd.error.bat[i,3] <- NA
    next
  }
  sd.error.bat[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.bat[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                           
  sd.error.bat[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                           
}
bat.error <- mean(sd.error.bat, na.rm=TRUE)
# Replace NAs by mean
sd.error.bat[is.na(sd.error.bat)] <- bat.error

# Combine error matrices
sd.error <- rbind(sd.error.hum,sd.error.gen,sd.error.bat)
sd.error <- sd.error[attr(random.trees,"TipLabel"),]


###
# Function to fit models

UniModelsFit <- function(tree, trait, states, error=NULL, ...){
  require(mvMORPH)
  require(OUwie)
  # tree is a mapped simmap tree
  # trait is a named vector of continuous values
  # states is a named vector of regime states
  # error is a named vector of standard errors
  # ... options are:
  # scaleHeight=TRUE, the default
  # root.station=TRUE, the default
  
  # Options
  par <- list(...)
  if(is.null(par[["root.station"]])){
    rootmvMORPH <- "stationary"
    rootOUwie <- TRUE
  }else{
    rootmvMORPH <- FALSE
    rootOUwie <- FALSE
  }
  
  if(is.null(par[["scaleHeight"]])){
    scaleHeight <- TRUE
  }else{
    scaleHeight <- FALSE  
  }
  
  # check data
  if(is.null(names(trait))) stop("trait vector must be named")
  if(is.null(names(states))) stop("states vector must be named")
  if(!inherits(tree,"simmap")) stop("tree should be an object of class \"simmap\".")
  
  if(is.null(error)){
    # dataframe for OUwie
    data <- data.frame(Species=tree$tip.label, 
                       Regimes=states[tree$tip.label],
                       trait=trait[tree$tip.label])
    # no error
    iSerr <- "none"
  }else{
    # dataframe for OUwie
    data <- data.frame(Species=tree$tip.label, 
                       Regimes=states[tree$tip.label],
                       trait=trait[tree$tip.label],
                       error=error[tree$tip.label])  
    # error is known
    iSerr <- "known"
  }

  # ---- OUwie models
  # OU1
  # OU1 <- OUwie(tree, data, model="OU1", simmap.tree=TRUE, 
  #              scaleHeight=scaleHeight, root.station=rootOUwie,
  #              mserr=iSerr, quiet=TRUE, warn=FALSE)
  # OUM
  # OUM <- OUwie(tree, data, model="OUM", simmap.tree=TRUE, 
  #              scaleHeight=scaleHeight, root.station=rootOUwie,
  #              mserr=iSerr, quiet=TRUE, warn=FALSE)
  # OUMV
  OUMV <- OUwie(tree, data, model="OUMV", simmap.tree=TRUE, 
                scaleHeight=scaleHeight, root.station=rootOUwie,
                mserr=iSerr, quiet=TRUE, warn=FALSE)
  # OUMA
  OUMA <- OUwie(tree, data, model="OUMA", simmap.tree=TRUE, 
                scaleHeight=scaleHeight, root.station=rootOUwie,
                mserr=iSerr, quiet=TRUE, warn=FALSE)
  # OUMVA
  OUMVA <- OUwie(tree, data, model="OUMVA", simmap.tree=TRUE, 
                 scaleHeight=scaleHeight, root.station=rootOUwie,
                 mserr=iSerr, quiet=TRUE, warn=FALSE)
  
  # ---- mvMORPH models
  errorsq <- error
  if(!is.null(errorsq)) errorsq=errorsq^2
  # BM1 model
  BM1 <- mvBM(tree, trait, error=errorsq, model="BM1", 
              method="rpf", scale.height=scaleHeight,
              diagnostic=FALSE, echo=FALSE)
  # BMM model
  BMM <- mvBM(tree, trait, error=errorsq, model="BMM", 
              method="rpf", scale.height=scaleHeight,
              diagnostic=FALSE, echo=FALSE)
  # BM1 with multiple phylogenetic mean (non-censored)
  BM1nc <- mvBM(tree, trait, error=errorsq, model="BM1", 
                method="rpf", param=list(smean=FALSE),
                scale.height=scaleHeight,
                diagnostic=FALSE, echo=FALSE)
  # BMM with multiple phylogenetic mean (non-censored)
  BMMnc <- mvBM(tree, trait, error=errorsq, model="BMM", 
                method="rpf", param=list(smean=FALSE),
                scale.height=scaleHeight,
                diagnostic=FALSE, echo=FALSE)
  # OU1 model
  OU1 <- mvOU(tree, trait, error=errorsq, model="OU1", 
               method="rpf", param=list(root=rootmvMORPH), scale.height=scaleHeight,
               diagnostic=FALSE, echo=FALSE)
  # OUM model
  OUM <- mvOU(tree, trait, error=errorsq, model="OUM", 
              method="rpf", param=list(root=rootmvMORPH), scale.height=scaleHeight,
              diagnostic=FALSE, echo=FALSE)
  
  # SHIFT model?
  if(ncol(tree$mapped.edge)==2){
    
    SHIFT1 <- mvSHIFT(tree, trait, error=errorsq, model="OUBMi", # can change it to OUBM
                      method="rpf", param=list(smean=FALSE),
                      scale.height=scaleHeight,
                      diagnostic=FALSE, echo=FALSE)  
    
    SHIFT2 <- mvSHIFT(tree, trait, error=errorsq, model="BMOUi", # can change it to BMOU
                      method="rpf", param=list(smean=FALSE),
                      scale.height=scaleHeight,
                      diagnostic=FALSE, echo=FALSE)   

    SHIFT3 <- mvSHIFT(tree, trait, error=errorsq, model="OUBM", # can change it to OUBM
                      method="rpf", param=list(smean=FALSE),
                      scale.height=scaleHeight,
                      diagnostic=FALSE, echo=FALSE)  
    
    SHIFT4 <- mvSHIFT(tree, trait, error=errorsq, model="BMOU", # can change it to BMOU
                      method="rpf", param=list(smean=FALSE),
                      scale.height=scaleHeight,
                      diagnostic=FALSE, echo=FALSE)   
    
    # Results table
    resultsFit <- data.frame(models=c("OU1","OUM","OUMV","OUMA","OUMVA","BM1"
                                      ,"BMM","BM1nc","BMMnc","SH1","SH2","SH3","SH4"),
                             logLik=c(OU1$LogLik,OUM$LogLik,OUMV$loglik,
                                      OUMA$loglik,OUMVA$loglik,BM1$LogLik,
                                      BMM$LogLik,BM1nc$LogLik,BMMnc$LogLik,
                                      SHIFT1$LogLik,SHIFT2$LogLik,SHIFT3$LogLik,SHIFT4$LogLik),
                             nparam=c(OU1$param$nparam,OUM$param$nparam,OUMV$param.count,
                                      OUMA$param.count,OUMVA$param.count,BM1$param$nparam,
                                      BMM$param$nparam,BM1nc$param$nparam,BMMnc$param$nparam,
                                      SHIFT1$param$nparam,SHIFT2$param$nparam,SHIFT3$param$nparam,SHIFT4$param$nparam),
                             convergence=c(OU1$convergence==0,OUM$convergence==0,all(OUMV$loglik>=0),
                                      all(OUMA$loglik>=0),all(OUMVA$loglik>0),BM1$convergence==0,
                                      BMM$convergence==0,BM1nc$convergence==0,BMMnc$convergence==0,
                                      SHIFT1$convergence==0,SHIFT2$convergence==0,SHIFT3$convergence==0,SHIFT4$convergence==0),
                             AIC=c(OU1$AIC,OUM$AIC,OUMV$AIC,
                                   OUMA$AIC,OUMVA$AIC,BM1$AIC,
                                   BMM$AIC,BM1nc$AIC,BMMnc$AIC,
                                   SHIFT1$AIC,SHIFT2$AIC,SHIFT3$AIC,SHIFT4$AIC),
                             AICc=c(OU1$AICc,OUM$AICc,OUMV$AICc,
                                    OUMA$AICc,OUMVA$AICc,BM1$AICc,
                                    BMM$AICc,BM1nc$AICc,BMMnc$AICc,
                                    SHIFT1$AICc,SHIFT2$AICc,SHIFT3$AICc,SHIFT4$AICc))
    resultsFit$AICdelta <- resultsFit$AIC-min(resultsFit$AIC)
    resultsFit$AICcdelta <- resultsFit$AICc-min(resultsFit$AICc)
    resultsFit$aicw <- exp(-0.5*resultsFit$AICdelta) / sum(exp(-0.5*resultsFit$AICdelta))
    resultsFit$aiccw <- exp(-0.5*resultsFit$AICcdelta) / sum(exp(-0.5*resultsFit$AICcdelta))

    listFit <- list(OU1=OU1, OUM=OUM, OUMV=OUMV, OUMA=OUMA, OUMVA=OUMVA,
                    BM1=BM1, BMM=BMM, BM1nc=BM1nc, BMMnc=BMMnc, SH1=SHIFT1,
                    SH2=SHIFT2,SH3=SHIFT3,SH4=SHIFT4)
    
  }else{
    
    # Results table
    resultsFit <- data.frame(models=c("OU1","OUM","OUMV","OUMA","OUMVA","BM1"
                                      ,"BMM","BM1nc","BMMnc"),
                             logLik=c(OU1$loglik,OUM$loglik,OUMV$loglik,
                                      OUMA$loglik,OUMVA$loglik,BM1$LogLik,
                                      BMM$LogLik,BM1nc$LogLik,BMMnc$LogLik),
                             nparam=c(OU1$param.count,OUM$param.count,OUMV$param.count,
                                      OUMA$param.count,OUMVA$param.count,BM1$param$nparam,
                                      BMM$param$nparam,BM1nc$param$nparam,BMMnc$param$nparam),
                             convergence=c(all(OU1$loglik>=0),all(OUM$loglik>=0),all(OUMV$loglik>=0),
                                           all(OUMA$loglik>=0),all(OUMVA$loglik>0),BM1$convergence==0,
                                           BMM$convergence==0,BM1nc$convergence==0,BMMnc$convergence==0),
                             AIC=c(OU1$AIC,OUM$AIC,OUMV$AIC,
                                   OUMA$AIC,OUMVA$AIC,BM1$AIC,
                                   BMM$AIC,BM1nc$AIC,BMMnc$AIC),
                             AICc=c(OU1$AICc,OUM$AICc,OUMV$AICc,
                                    OUMA$AICc,OUMVA$AICc,BM1$AICc,
                                    BMM$AICc,BM1nc$AICc,BMMnc$AICc))
    resultsFit$AICdelta <- resultsFit$AIC-min(resultsFit$AIC)
    resultsFit$AICcdelta <- resultsFit$AICc-min(resultsFit$AICc)
    resultsFit$aicw <- exp(-0.5*resultsFit$AICdelta) / sum(exp(-0.5*resultsFit$AICdelta))
    resultsFit$aiccw <- exp(-0.5*resultsFit$AICcdelta) / sum(exp(-0.5*resultsFit$AICcdelta))
    
    listFit <- list(OU1=OU1, OUM=OUM, OUMV=OUMV, OUMA=OUMA, OUMVA=OUMVA,
                    BM1=BM1, BMM=BMM, BM1nc=BM1nc, BMMnc=BMMnc)
  } # end else
  
  #print(resultsFit)
  # Return the results
  results <- list(resultsFit, listFit)
  invisible(results)
}


###
# Functions to summarize results

# Table with standard deviations
param.table.univar <- function(fit, precision=2) {
  models=factor(c("OU1","OUM","OUMV","OUMA","OUMVA","BM1","BMV","BM1m","BMVm","OUBMr","BMOUr","OUBM","BMOU"),
                levels=c("BM1","BMV","BM1m","BMVm","OU1","OUM","OUMV","OUMA","OUMVA","OUBMr","BMOUr","OUBM","BMOU"))
  logLik <- data.frame(logLik=c(sapply(fit[1,],"[[","logLik")),models=models)
  logLik.m <- apply(unstack(logLik,select=models),2,mean)
  logLik.sd <- apply(unstack(logLik,select=models),2,sd)
  nparam <- data.frame(nparam=c(sapply(fit[1,1],"[[","nparam")),models=models)
  nparam <- nparam[match(levels(models),nparam$models),]
  aicc <- data.frame(aic=c(sapply(fit[1,],"[[","AICc")),models=models)
  aicc.m <- apply(unstack(aicc,select=models),2,mean)
  aicc.sd <- apply(unstack(aicc,select=models),2,sd)
  aicc.vals <- sapply(fit[1,],"[[","AICc")
  aicc.delta <- sapply(c(1:ncol(aicc.vals)), function(x) aicc.vals[,x]-min(aicc.vals[,x]))
  aiccw <- sapply(c(1:ncol(aicc.vals)), function(x) exp(-0.5*aicc.delta[,x]) / sum(exp(-0.5*aicc.delta[,x])))
  rownames(aiccw) <- models
  aiccw <- aiccw[levels(models),]
  aiccw.m <- apply(aiccw,1,mean)
  aiccw.sd <- apply(aiccw,1,sd)
  
  theta_h.m <- numeric(13)
  names(theta_h.m) <- levels(models)
  theta_h.m[1] <- median(unlist(sapply(fit[2,],"[[","BM1")["theta",]))
  theta_h.m[2] <- median(unlist(sapply(fit[2,],"[[","BMM")["theta",]))
  theta_h.m[3] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],as.vector),1,median)[1]
  theta_h.m[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],as.vector),1,median)[1]
  theta_h.m[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["theta",],as.vector),1,median)[1]
  theta_h.m[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],as.vector),1,median)[1]
  theta_h.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["theta",],as.vector),1,median)[1]
  theta_h.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["theta",],as.vector),1,median)[1]
  theta_h.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["theta",],as.vector),1,median)[1]
  theta_h.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["theta",]))
  theta_h.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["theta",]))
  theta_h.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["theta",]))
  theta_h.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["theta",]))
  
  theta_h.sd <- numeric(13)
  names(theta_h.sd) <- levels(models)
  theta_h.sd[1] <- sd(unlist(sapply(fit[2,],"[[","BM1")["theta",]))
  theta_h.sd[2] <- sd(unlist(sapply(fit[2,],"[[","BMM")["theta",]))
  theta_h.sd[3] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],as.vector),1,sd)[1]
  theta_h.sd[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],as.vector),1,sd)[1]
  theta_h.sd[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["theta",],as.vector),1,sd)[1]
  theta_h.sd[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],as.vector),1,sd)[1]
  theta_h.sd[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["theta",],as.vector),1,sd)[1]
  theta_h.sd[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["theta",],as.vector),1,sd)[1]
  theta_h.sd[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["theta",],as.vector),1,sd)[1]
  theta_h.sd[10] <- sd(unlist(sapply(fit[2,],"[[","SH1")["theta",]))
  theta_h.sd[11] <- sd(unlist(sapply(fit[2,],"[[","SH2")["theta",]))
  theta_h.sd[12] <- sd(unlist(sapply(fit[2,],"[[","SH3")["theta",]))
  theta_h.sd[13] <- sd(unlist(sapply(fit[2,],"[[","SH4")["theta",]))
  
  sigma_h.m <- numeric(13)
  names(sigma_h.m) <- levels(models)
  sigma_h.m[1] <- median(unlist(sapply(fit[2,],"[[","BM1")["sigma",]))
  sigma_h.m[2] <- apply(sapply(sapply(fit[2,],"[[","BMM")["sigma",],as.vector),1,median)[1]
  sigma_h.m[3] <- median(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]))
  sigma_h.m[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["sigma",],as.vector),1,median)[1]
  sigma_h.m[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,median)[2]
  sigma_h.m[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,median)[2]
  sigma_h.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[2]
  sigma_h.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[2]
  sigma_h.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[2]
  sigma_h.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["sigma",]))
  sigma_h.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["sig",]))
  sigma_h.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["sigma",]))
  sigma_h.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["sigma",]))
  
  sigma_h.sd <- numeric(13)
  names(sigma_h.sd) <- levels(models)
  sigma_h.sd[1] <- sd(unlist(sapply(fit[2,],"[[","BM1")["sigma",]))
  sigma_h.sd[2] <- apply(sapply(sapply(fit[2,],"[[","BMM")["sigma",],as.vector),1,sd)[1]
  sigma_h.sd[3] <- sd(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]))
  sigma_h.sd[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["sigma",],as.vector),1,sd)[1]
  sigma_h.sd[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,sd)[2]
  sigma_h.sd[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,sd)[2]
  sigma_h.sd[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,sd)[2]
  sigma_h.sd[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,sd)[2]
  sigma_h.sd[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,sd)[2]
  sigma_h.sd[10] <- sd(unlist(sapply(fit[2,],"[[","SH1")["sigma",]))
  sigma_h.sd[11] <- sd(unlist(sapply(fit[2,],"[[","SH2")["sig",]))
  sigma_h.sd[12] <- sd(unlist(sapply(fit[2,],"[[","SH3")["sigma",]))
  sigma_h.sd[13] <- sd(unlist(sapply(fit[2,],"[[","SH4")["sigma",]))
  
  # alpha_hum <- numeric(11)
  # names(alpha_hum) <- levels(models)
  # alpha_hum[c(1:4,11)] <- NA
  # alpha_hum[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,median)[1]
  # alpha_hum[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,median)[1]
  # alpha_hum[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[1]
  # alpha_hum[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[1]
  # alpha_hum[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[1]
  # alpha_hum[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["alpha",]))
  
  half_h.m <- numeric(13)
  names(half_h.m) <- levels(models)
  half_h.m[c(1:4,11,13)] <- NA
  half_h.m[5] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,median)[1]
  half_h.m[6] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,median)[1]
  half_h.m[7] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[1]
  half_h.m[8] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[1]
  half_h.m[9] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[1]
  half_h.m[10] <- log(2)/median(unlist(sapply(fit[2,],"[[","SH1")["alpha",]))
  half_h.m[12] <- log(2)/median(unlist(sapply(fit[2,],"[[","SH3")["alpha",]))
  
  half_h.sd <- numeric(13)
  names(half_h.sd) <- levels(models)
  half_h.sd[c(1:4,11,13)] <- NA
  half_h.sd[5] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,sd)[1]
  half_h.sd[6] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,sd)[1]
  half_h.sd[7] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,sd)[1]
  half_h.sd[8] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,sd)[1]
  half_h.sd[9] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,sd)[1]
  half_h.sd[10] <- log(2)/sd(unlist(sapply(fit[2,],"[[","SH1")["alpha",]))
  half_h.sd[12] <- log(2)/sd(unlist(sapply(fit[2,],"[[","SH3")["alpha",]))
  
  station_h.m <- numeric(13)
  names(station_h.m) <- levels(models)
  station_h.m[c(1:4,11,13)] <- NA
  station_h.m[5] <- median((sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector)[1,])))
  station_h.m[6] <- median((sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector)[1,])))
  station_h.m[7] <- median((sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[1,])))
  station_h.m[8] <- median((sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[1,])))
  station_h.m[9] <- median((sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[1,])))
  station_h.m[10] <- median(sapply(lapply(fit[2,],"[[","SH1"),stationary))
  station_h.m[12] <- median(sapply(lapply(fit[2,],"[[","SH3"),stationary))
  
  station_h.sd <- numeric(13)
  names(station_h.sd) <- levels(models)
  station_h.sd[c(1:4,11,13)] <- NA
  station_h.sd[5] <- sd((sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector)[1,])))
  station_h.sd[6] <- sd((sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector)[1,])))
  station_h.sd[7] <- sd((sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[1,])))
  station_h.sd[8] <- sd((sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[1,])))
  station_h.sd[9] <- sd((sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[1,])))
  station_h.sd[10] <- sd(sapply(lapply(fit[2,],"[[","SH1"),stationary))
  station_h.sd[12] <- sd(sapply(lapply(fit[2,],"[[","SH3"),stationary))
  
  theta_g.m <- numeric(13)
  names(theta_g.m) <- levels(models)
  theta_g.m[1] <- median(unlist(sapply(fit[2,],"[[","BM1")["theta",]))
  theta_g.m[2] <- median(unlist(sapply(fit[2,],"[[","BMM")["theta",]))
  theta_g.m[3] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],as.vector),1,median)[2]
  theta_g.m[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],as.vector),1,median)[2]
  theta_g.m[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["theta",],as.vector),1,median)[1]
  theta_g.m[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],as.vector),1,median)[2]
  theta_g.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["theta",],as.vector),1,median)[2]
  theta_g.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["theta",],as.vector),1,median)[2]
  theta_g.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["theta",],as.vector),1,median)[2]
  theta_g.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["theta",]))
  theta_g.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["theta",]))
  theta_g.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["theta",]))
  theta_g.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["theta",]))
  
  theta_g.sd <- numeric(13)
  names(theta_g.sd) <- levels(models)
  theta_g.sd[1] <- sd(unlist(sapply(fit[2,],"[[","BM1")["theta",]))
  theta_g.sd[2] <- sd(unlist(sapply(fit[2,],"[[","BMM")["theta",]))
  theta_g.sd[3] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],as.vector),1,sd)[2]
  theta_g.sd[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],as.vector),1,sd)[2]
  theta_g.sd[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["theta",],as.vector),1,sd)[1]
  theta_g.sd[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],as.vector),1,sd)[2]
  theta_g.sd[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["theta",],as.vector),1,sd)[2]
  theta_g.sd[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["theta",],as.vector),1,sd)[2]
  theta_g.sd[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["theta",],as.vector),1,sd)[2]
  theta_g.sd[10] <- sd(unlist(sapply(fit[2,],"[[","SH1")["theta",]))
  theta_g.sd[11] <- sd(unlist(sapply(fit[2,],"[[","SH2")["theta",]))
  theta_g.sd[12] <- sd(unlist(sapply(fit[2,],"[[","SH3")["theta",]))
  theta_g.sd[13] <- sd(unlist(sapply(fit[2,],"[[","SH4")["theta",]))
  
  sigma_g.m <- numeric(13)
  names(sigma_g.m) <- levels(models)
  sigma_g.m[1] <- median(unlist(sapply(fit[2,],"[[","BM1")["sigma",]))
  sigma_g.m[2] <- apply(sapply(sapply(fit[2,],"[[","BMM")["sigma",],as.vector),1,median)[2]
  sigma_g.m[3] <- median(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]))
  sigma_g.m[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["sigma",],as.vector),1,median)[2]
  sigma_g.m[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,median)[4]
  sigma_g.m[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,median)[4]
  sigma_g.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[4]
  sigma_g.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[4]
  sigma_g.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[4]
  sigma_g.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["sig",]))
  sigma_g.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["sigma",]))
  sigma_g.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["sigma",]))
  sigma_g.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["sigma",]))
  
  sigma_g.sd <- numeric(13)
  names(sigma_g.sd) <- levels(models)
  sigma_g.sd[1] <- sd(unlist(sapply(fit[2,],"[[","BM1")["sigma",]))
  sigma_g.sd[2] <- apply(sapply(sapply(fit[2,],"[[","BMM")["sigma",],as.vector),1,sd)[2]
  sigma_g.sd[3] <- sd(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]))
  sigma_g.sd[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["sigma",],as.vector),1,sd)[2]
  sigma_g.sd[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,sd)[4]
  sigma_g.sd[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,sd)[4]
  sigma_g.sd[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,sd)[4]
  sigma_g.sd[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,sd)[4]
  sigma_g.sd[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,sd)[4]
  sigma_g.sd[10] <- sd(unlist(sapply(fit[2,],"[[","SH1")["sig",]))
  sigma_g.sd[11] <- sd(unlist(sapply(fit[2,],"[[","SH2")["sigma",]))
  sigma_g.sd[12] <- sd(unlist(sapply(fit[2,],"[[","SH3")["sigma",]))
  sigma_g.sd[13] <- sd(unlist(sapply(fit[2,],"[[","SH4")["sigma",]))
  
  # alpha_gen <- numeric(11)
  # names(alpha_gen) <- levels(models)
  # alpha_gen[c(1:4,10)] <- NA
  # alpha_gen[5] <- apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,median)[3]
  # alpha_gen[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,median)[3]
  # alpha_gen[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[3]
  # alpha_gen[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[3]
  # alpha_gen[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[3]
  # alpha_gen[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["alpha",]))
  
  half_g.m <- numeric(13)
  names(half_g.m) <- levels(models)
  half_g.m[c(1:4,10,12)] <- NA
  half_g.m[5] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,median)[3]
  half_g.m[6] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,median)[3]
  half_g.m[7] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[3]
  half_g.m[8] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[3]
  half_g.m[9] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[3]
  half_g.m[11] <- log(2)/median(unlist(sapply(fit[2,],"[[","SH2")["alpha",]))
  half_g.m[13] <- log(2)/median(unlist(sapply(fit[2,],"[[","SH4")["alpha",]))
  
  half_g.sd <- numeric(13)
  names(half_g.sd) <- levels(models)
  half_g.sd[c(1:4,10,12)] <- NA
  half_g.sd[5] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector),1,sd)[3]
  half_g.sd[6] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector),1,sd)[3]
  half_g.sd[7] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,sd)[3]
  half_g.sd[8] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,sd)[3]
  half_g.sd[9] <- log(2)/apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,sd)[3]
  half_g.sd[11] <- log(2)/sd(unlist(sapply(fit[2,],"[[","SH2")["alpha",]))
  half_g.sd[13] <- log(2)/sd(unlist(sapply(fit[2,],"[[","SH4")["alpha",]))
  
  station_g.m <- numeric(13)
  names(station_g.m) <- levels(models)
  station_g.m[c(1:4,10,12)] <- NA
  station_g.m[5] <- median((sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector)[3,])))
  station_g.m[6] <- median((sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector)[3,])))
  station_g.m[7] <- median((sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[3,])))
  station_g.m[8] <- median((sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[3,])))
  station_g.m[9] <- median((sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[3,])))
  station_g.m[11] <- median(sapply(lapply(fit[2,],"[[","SH2"),stationary))
  station_g.m[13] <- median(sapply(lapply(fit[2,],"[[","SH4"),stationary))
  
  station_g.sd <- numeric(13)
  names(station_g.sd) <- levels(models)
  station_g.sd[c(1:4,10,12)] <- NA
  station_g.sd[5] <- sd((sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OU1")["solution",],as.vector)[3,])))
  station_g.sd[6] <- sd((sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUM")["solution",],as.vector)[3,])))
  station_g.sd[7] <- sd((sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[3,])))
  station_g.sd[8] <- sd((sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[3,])))
  station_g.sd[9] <- sd((sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[3,])))
  station_g.sd[11] <- sd(sapply(lapply(fit[2,],"[[","SH2"),stationary))
  station_g.sd[13] <- sd(sapply(lapply(fit[2,],"[[","SH4"),stationary))
  
  med.results <- data.frame(logLik=logLik.m, param=nparam[,1], AICc=aicc.m, 
                            theta.h=theta_h.m, theta.g=theta_g.m,
                            sigma.h=sigma_h.m, sigma.g=sigma_g.m,
                            station.h=station_h.m, station.g=station_g.m)
  results.print <- data.frame(models=levels(models),
                              logLik=paste(round(logLik.m,1),round(logLik.sd,1),sep="±"), 
                              param=round(nparam[,1],0), 
                              AICc=paste(round(aicc.m,1),round(aicc.sd,1),sep="±"),
                              AICcw=paste(round(aiccw.m,2),round(aiccw.sd,2),sep="±"),
                              theta.h=paste(round(theta_h.m,3),round(theta_h.sd,3),sep="±"),
                              theta.g=paste(round(theta_g.m,3),round(theta_g.sd,3),sep="±"),
                              sigma.h=paste(round(sigma_h.m,3),round(sigma_h.sd,3),sep="±"),
                              sigma.g=paste(round(sigma_g.m,3),round(sigma_g.sd,3),sep="±"),
                              half.time.h=paste(round(half_h.m,3),round(half_h.sd,3),sep="±"),
                              half.time.g=paste(round(half_g.m,3),round(half_g.sd,3),sep="±"),
                              station.h=paste(round(station_h.m,3),round(station_h.sd,3),sep="±"),
                              station.g=paste(round(station_g.m,3),round(station_g.sd,3),sep="±"))
  print(results.print)
  invisible(results.print)
}

# Table with quantiles
param.table.univar <- function(fit, precision=2) {
  models=factor(c("OU1","OUM","OUMV","OUMA","OUMVA","BM1","BMV","BM1m","BMVm","OUBMr","BMOUr","OUBM","BMOU"),
                levels=c("BM1","BMV","BM1m","BMVm","OU1","OUM","OUMV","OUMA","OUMVA","OUBMr","BMOUr","OUBM","BMOU"))
  
  fig.dat <- data.frame(value=numeric(),q25=numeric(),q75=numeric(),syndrome=character(),models=factor(levels=levels(models)),param=character())
  
  nparam <- data.frame(nparam=c(sapply(fit[1,1],"[[","nparam")),models=models)
  nparam <- nparam[match(levels(models),nparam$models),]
  
  fig.dat <- rbind(fig.dat,data.frame(value=nparam[,1],q25=NA,q75=NA,
                                      syndrome="both",models=levels(models),param="param"))
  
  logLik <- data.frame(logLik=c(sapply(fit[1,],"[[","logLik")),models=models)
  logLik.m <- apply(unstack(logLik,select=models),2,mean)
  logLik.50 <- apply(unstack(logLik,select=models),2,function(c) quantile(c,probs=c(0.25,0.75)))
  
  fig.dat <- rbind(fig.dat,data.frame(value=logLik.m,q25=logLik.50[1,],q75=logLik.50[2,],
                                      syndrome="both",models=levels(models),param="logLik"))
  
  aicc <- data.frame(aic=c(sapply(fit[1,],"[[","AICc")),models=models)
  aicc.m <- apply(unstack(aicc,select=models),2,mean)
  aicc.50 <- apply(unstack(aicc,select=models),2,function(c) quantile(c,probs=c(0.25,0.75)))
  
  fig.dat <- rbind(fig.dat,data.frame(value=aicc.m,q25=aicc.50[1,],q75=aicc.50[2,],
                                      syndrome="both",models=levels(models),param="AICc"))
  
  aicc.vals <- sapply(fit[1,],"[[","AICc")
  aicc.delta <- sapply(c(1:ncol(aicc.vals)), function(x) aicc.vals[,x]-min(aicc.vals[,x]))
  aiccw <- sapply(c(1:ncol(aicc.vals)), function(x) exp(-0.5*aicc.delta[,x]) / sum(exp(-0.5*aicc.delta[,x])))
  rownames(aiccw) <- models
  aiccw <- aiccw[levels(models),]
  aiccw.m <- apply(aiccw,1,mean)
  aiccw.50 <- apply(aiccw,1,function(c) quantile(c,probs=c(0.25,0.75)))
  
  fig.dat <- rbind(fig.dat,data.frame(value=aiccw.m,q25=aiccw.50[1,],q75=aiccw.50[2,],
                                      syndrome="both",models=levels(models),param="AICc weights"))
  
  theta_h.m <- numeric(13)
  names(theta_h.m) <- levels(models)
  theta_h.m[1] <- median(unlist(sapply(fit[2,],"[[","BM1")["theta",]))
  theta_h.m[2] <- median(unlist(sapply(fit[2,],"[[","BMM")["theta",]))
  theta_h.m[3] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],as.vector),1,median)[1]
  theta_h.m[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],as.vector),1,median)[1]
  theta_h.m[5] <- median(unlist(sapply(fit[2,],"[[","OU1")["theta",]))
  theta_h.m[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],as.vector),1,median)[1]
  theta_h.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["theta",],as.vector),1,median)[1]
  theta_h.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["theta",],as.vector),1,median)[1]
  theta_h.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["theta",],as.vector),1,median)[1]
  theta_h.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["theta",]))
  theta_h.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["theta",]))
  theta_h.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["theta",]))
  theta_h.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["theta",]))
  
  theta_h.50 <- matrix(ncol=13,nrow=2)
  colnames(theta_h.50) <- levels(models)
  theta_h.50[,1] <- quantile(unlist(sapply(fit[2,],"[[","BM1")["theta",]),probs=c(0.25,0.75))
  theta_h.50[,2] <- quantile(unlist(sapply(fit[2,],"[[","BMM")["theta",]),probs=c(0.25,0.75))
  theta_h.50[,3] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,1]
  theta_h.50[,4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,1]
  theta_h.50[,5] <- quantile(unlist(sapply(fit[2,],"[[","OU1")["theta",]),probs=c(0.25,0.75))
  theta_h.50[,6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,1]
  theta_h.50[,7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,1]
  theta_h.50[,8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,1]
  theta_h.50[,9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,1]
  theta_h.50[,10] <- quantile(unlist(sapply(fit[2,],"[[","SH1")["theta",]),probs=c(0.25,0.75))
  theta_h.50[,11] <- quantile(unlist(sapply(fit[2,],"[[","SH2")["theta",]),probs=c(0.25,0.75))
  theta_h.50[,12] <- quantile(unlist(sapply(fit[2,],"[[","SH3")["theta",]),probs=c(0.25,0.75))
  theta_h.50[,13] <- quantile(unlist(sapply(fit[2,],"[[","SH4")["theta",]),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=theta_h.m,q25=theta_h.50[1,],q75=theta_h.50[2,],
                                      syndrome="hummingbird",models=levels(models),param="theta"))
  
  sigma_h.m <- numeric(13)
  names(sigma_h.m) <- levels(models)
  sigma_h.m[1] <- median(unlist(sapply(fit[2,],"[[","BM1")["sigma",]))
  sigma_h.m[2] <- apply(sapply(sapply(fit[2,],"[[","BMM")["sigma",],as.vector),1,median)[1]
  sigma_h.m[3] <- median(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]))
  sigma_h.m[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["sigma",],as.vector),1,median)[1]
  sigma_h.m[5] <- median(unlist(sapply(fit[2,],"[[","OU1")["sigma",]))
  sigma_h.m[6] <- median(unlist(sapply(fit[2,],"[[","OUM")["sigma",]))
  sigma_h.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[2]
  sigma_h.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[2]
  sigma_h.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[2]
  sigma_h.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["sigma",]))
  sigma_h.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["sig",]))
  sigma_h.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["sigma",]))
  sigma_h.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["sigma",]))
  
  sigma_h.50 <- matrix(ncol=13,nrow=2)
  colnames(sigma_h.50) <- levels(models)
  sigma_h.50[,1] <- quantile(unlist(sapply(fit[2,],"[[","BM1")["sigma",]),probs=c(0.25,0.75))
  sigma_h.50[,2] <- apply(sapply(sapply(fit[2,],"[[","BMM")["sigma",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,1]
  sigma_h.50[,3] <- quantile(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]),probs=c(0.25,0.75))
  sigma_h.50[,4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["sigma",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,1]
  sigma_h.50[,5] <- quantile(unlist(sapply(fit[2,],"[[","OU1")["sigma",]),probs=c(0.25,0.75))
  sigma_h.50[,6] <- quantile(unlist(sapply(fit[2,],"[[","OUM")["sigma",]),probs=c(0.25,0.75))
  sigma_h.50[,7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  sigma_h.50[,8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  sigma_h.50[,9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  sigma_h.50[,10] <- quantile(unlist(sapply(fit[2,],"[[","SH1")["sigma",]),probs=c(0.25,0.75))
  sigma_h.50[,11] <- quantile(unlist(sapply(fit[2,],"[[","SH2")["sig",]),probs=c(0.25,0.75))
  sigma_h.50[,12] <- quantile(unlist(sapply(fit[2,],"[[","SH3")["sigma",]),probs=c(0.25,0.75))
  sigma_h.50[,13] <- quantile(unlist(sapply(fit[2,],"[[","SH4")["sigma",]),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=sigma_h.m,q25=sigma_h.50[1,],q75=sigma_h.50[2,],
                                      syndrome="hummingbird",models=levels(models),param="sigma"))
  
  alpha_h.m <- numeric(13)
  names(alpha_h.m) <- levels(models)
  alpha_h.m[c(1:4,11,13)] <- NA
  alpha_h.m[5] <- median(unlist(sapply(fit[2,],"[[","OU1")["alpha",]))
  alpha_h.m[6] <- median(unlist(sapply(fit[2,],"[[","OUM")["alpha",]))
  alpha_h.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[1]
  alpha_h.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[1]
  alpha_h.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[1]
  alpha_h.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["alpha",]))
  alpha_h.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["alpha",]))
  
  alpha_h.50 <- matrix(ncol=13,nrow=2)
  colnames(alpha_h.50) <- levels(models)
  alpha_h.50[,5] <- quantile(unlist(sapply(fit[2,],"[[","OU1")["alpha",]),probs=c(0.25,0.75))
  alpha_h.50[,6] <- quantile(unlist(sapply(fit[2,],"[[","OUM")["alpha",]),probs=c(0.25,0.75))
  alpha_h.50[,7] <- quantile(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[1,],probs=c(0.25,0.75))
  alpha_h.50[,8] <- quantile(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[1,],probs=c(0.25,0.75))
  alpha_h.50[,9] <- quantile(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[1,],probs=c(0.25,0.75))
  alpha_h.50[,10] <- quantile(unlist(sapply(fit[2,],"[[","SH1")["alpha",]),probs=c(0.25,0.75))
  alpha_h.50[,12] <- quantile(unlist(sapply(fit[2,],"[[","SH3")["alpha",]),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=alpha_h.m,q25=alpha_h.50[1,],q75=alpha_h.50[2,],
                                      syndrome="hummingbird",models=levels(models),param="alpha"))
  
  half_h.m <- numeric(13)
  names(half_h.m) <- levels(models)
  half_h.m[c(1:4,11,13)] <- NA
  half_h.m[5] <- median(log(2)/unlist(sapply(fit[2,],"[[","OU1")["alpha",]))
  half_h.m[6] <- median(log(2)/unlist(sapply(fit[2,],"[[","OUM")["alpha",]))
  half_h.m[7] <- median(log(2)/sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[1,])
  half_h.m[8] <- median(log(2)/sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[1,])
  half_h.m[9] <- median(log(2)/sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[1,])
  half_h.m[10] <- median(log(2)/unlist(sapply(fit[2,],"[[","SH1")["alpha",]))
  half_h.m[12] <- median(log(2)/unlist(sapply(fit[2,],"[[","SH3")["alpha",]))
  
  half_h.50 <- matrix(ncol=13,nrow=2)
  colnames(half_h.50) <- levels(models)
  half_h.50[,5] <- quantile(log(2)/unlist(sapply(fit[2,],"[[","OU1")["alpha",]),probs=c(0.25,0.75))
  half_h.50[,6] <- quantile(log(2)/unlist(sapply(fit[2,],"[[","OUM")["alpha",]),probs=c(0.25,0.75))
  half_h.50[,7] <- quantile(log(2)/sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[1,],probs=c(0.25,0.75))
  half_h.50[,8] <- quantile(log(2)/sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[1,],probs=c(0.25,0.75))
  half_h.50[,9] <- quantile(log(2)/sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[1,],probs=c(0.25,0.75))
  half_h.50[,10] <- quantile(log(2)/unlist(sapply(fit[2,],"[[","SH1")["alpha",]),probs=c(0.25,0.75))
  half_h.50[,12] <- quantile(log(2)/unlist(sapply(fit[2,],"[[","SH3")["alpha",]),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=half_h.m,q25=half_h.50[1,],q75=half_h.50[2,],
                                      syndrome="hummingbird",models=levels(models),param="half-life"))
  
  station_h.m <- numeric(13)
  station_h.m[c(1:4,11,13)] <- NA
  station_h.m[5] <- median(sapply(lapply(fit[2,],"[[","OU1"),stationary))
  station_h.m[6] <- median(sapply(lapply(fit[2,],"[[","OUM"),stationary))
  station_h.m[7] <- median((sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[1,])))
  station_h.m[8] <- median((sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[1,])))
  station_h.m[9] <- median((sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[1,])))
  station_h.m[10] <- median(sapply(lapply(fit[2,],"[[","SH1"),stationary))
  station_h.m[12] <- median(sapply(lapply(fit[2,],"[[","SH3"),stationary))
  
  station_h.50 <- matrix(ncol=13,nrow=2)
  colnames(station_h.50) <- levels(models)
  station_h.50[,5] <- quantile(sapply(lapply(fit[2,],"[[","OU1"),stationary),probs=c(0.25,0.75))
  station_h.50[,6] <- quantile(sapply(lapply(fit[2,],"[[","OUM"),stationary),probs=c(0.25,0.75))
  station_h.50[,7] <- quantile((sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[1,])),probs=c(0.25,0.75))
  station_h.50[,8] <- quantile((sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[1,])),probs=c(0.25,0.75))
  station_h.50[,9] <- quantile((sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[2,]/(2*sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[1,])),probs=c(0.25,0.75))
  station_h.50[,10] <- quantile(sapply(lapply(fit[2,],"[[","SH1"),stationary),probs=c(0.25,0.75))
  station_h.50[,12] <- quantile(sapply(lapply(fit[2,],"[[","SH3"),stationary),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=station_h.m,q25=station_h.50[1,],q75=station_h.50[2,],
                                      syndrome="hummingbird",models=levels(models),param="stationary variance"))
  
  theta_g.m <- numeric(13)
  names(theta_g.m) <- levels(models)
  theta_g.m[1] <- median(unlist(sapply(fit[2,],"[[","BM1")["theta",]))
  theta_g.m[2] <- median(unlist(sapply(fit[2,],"[[","BMM")["theta",]))
  theta_g.m[3] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],as.vector),1,median)[2]
  theta_g.m[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],as.vector),1,median)[2]
  theta_g.m[5] <- median(unlist(sapply(fit[2,],"[[","OU1")["theta",]))
  theta_g.m[6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],as.vector),1,median)[2]
  theta_g.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["theta",],as.vector),1,median)[2]
  theta_g.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["theta",],as.vector),1,median)[2]
  theta_g.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["theta",],as.vector),1,median)[2]
  theta_g.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["theta",]))
  theta_g.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["theta",]))
  theta_g.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["theta",]))
  theta_g.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["theta",]))
  
  theta_g.50 <- matrix(ncol=13,nrow=2)
  colnames(theta_g.50) <- levels(models)
  theta_g.50[,1] <- quantile(unlist(sapply(fit[2,],"[[","BM1")["theta",]),probs=c(0.25,0.75))
  theta_g.50[,2] <- quantile(unlist(sapply(fit[2,],"[[","BMM")["theta",]),probs=c(0.25,0.75))
  theta_g.50[,3] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  theta_g.50[,4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  theta_g.50[,5] <- quantile(unlist(sapply(fit[2,],"[[","OU1")["theta",]),probs=c(0.25,0.75))
  theta_g.50[,6] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  theta_g.50[,7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  theta_g.50[,8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  theta_g.50[,9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["theta",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  theta_g.50[,10] <- quantile(unlist(sapply(fit[2,],"[[","SH1")["theta",]),probs=c(0.25,0.75))
  theta_g.50[,11] <- quantile(unlist(sapply(fit[2,],"[[","SH2")["theta",]),probs=c(0.25,0.75))
  theta_g.50[,12] <- quantile(unlist(sapply(fit[2,],"[[","SH3")["theta",]),probs=c(0.25,0.75))
  theta_g.50[,13] <- quantile(unlist(sapply(fit[2,],"[[","SH4")["theta",]),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=theta_g.m,q25=theta_g.50[1,],q75=theta_g.50[2,],
                                      syndrome="mixed-pollination",models=levels(models),param="theta"))
  
  sigma_g.m <- numeric(13)
  names(sigma_g.m) <- levels(models)
  sigma_g.m[1] <- median(unlist(sapply(fit[2,],"[[","BM1")["sigma",]))
  sigma_g.m[2] <- apply(sapply(sapply(fit[2,],"[[","BMM")["sigma",],as.vector),1,median)[2]
  sigma_g.m[3] <- median(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]))
  sigma_g.m[4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["sigma",],as.vector),1,median)[2]
  sigma_g.m[5] <- median(unlist(sapply(fit[2,],"[[","OU1")["sigma",]))
  sigma_g.m[6] <- median(unlist(sapply(fit[2,],"[[","OUM")["sigma",]))
  sigma_g.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[4]
  sigma_g.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[4]
  sigma_g.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[4]
  sigma_g.m[10] <- median(unlist(sapply(fit[2,],"[[","SH1")["sig",]))
  sigma_g.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["sigma",]))
  sigma_g.m[12] <- median(unlist(sapply(fit[2,],"[[","SH3")["sigma",]))
  sigma_g.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["sigma",]))
  
  sigma_g.50 <- matrix(ncol=13,nrow=2)
  colnames(sigma_g.50) <- levels(models)
  sigma_g.50[,1] <- quantile(unlist(sapply(fit[2,],"[[","BM1")["sigma",]),probs=c(0.25,0.75))
  sigma_g.50[,2] <- apply(sapply(sapply(fit[2,],"[[","BMM")["sigma",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  sigma_g.50[,3] <- quantile(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]),probs=c(0.25,0.75))
  sigma_g.50[,4] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["sigma",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,2]
  sigma_g.50[,5] <- quantile(unlist(sapply(fit[2,],"[[","OU1")["sigma",]),probs=c(0.25,0.75))
  sigma_g.50[,6] <- quantile(unlist(sapply(fit[2,],"[[","OUM")["sigma",]),probs=c(0.25,0.75))
  sigma_g.50[,7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,4]
  sigma_g.50[,8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,4]
  sigma_g.50[,9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,function(c) quantile(c,probs=c(0.25,0.75)))[,4]
  sigma_g.50[,10] <- quantile(unlist(sapply(fit[2,],"[[","SH1")["sig",]),probs=c(0.25,0.75))
  sigma_g.50[,11] <- quantile(unlist(sapply(fit[2,],"[[","SH2")["sigma",]),probs=c(0.25,0.75))
  sigma_g.50[,12] <- quantile(unlist(sapply(fit[2,],"[[","SH3")["sigma",]),probs=c(0.25,0.75))
  sigma_g.50[,13] <- quantile(unlist(sapply(fit[2,],"[[","SH4")["sigma",]),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=sigma_g.m,q25=sigma_g.50[1,],q75=sigma_g.50[2,],
                                      syndrome="mixed-pollination",models=levels(models),param="sigma"))
  
  alpha_g.m <- numeric(13)
  names(alpha_g.m) <- levels(models)
  alpha_g.m[c(1:4,10,12)] <- NA
  alpha_g.m[5] <- median(unlist(sapply(fit[2,],"[[","OU1")["alpha",]))
  alpha_g.m[6] <- median(unlist(sapply(fit[2,],"[[","OUM")["alpha",]))
  alpha_g.m[7] <- apply(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector),1,median)[3]
  alpha_g.m[8] <- apply(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector),1,median)[3]
  alpha_g.m[9] <- apply(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector),1,median)[3]
  alpha_g.m[11] <- median(unlist(sapply(fit[2,],"[[","SH2")["alpha",]))
  alpha_g.m[13] <- median(unlist(sapply(fit[2,],"[[","SH4")["alpha",]))
  
  alpha_g.50 <- matrix(ncol=13,nrow=2)
  colnames(alpha_g.50) <- levels(models)
  alpha_g.50[,5] <- quantile(unlist(sapply(fit[2,],"[[","OU1")["alpha",]),probs=c(0.25,0.75))
  alpha_g.50[,6] <- quantile(unlist(sapply(fit[2,],"[[","OUM")["alpha",]),probs=c(0.25,0.75))
  alpha_g.50[,7] <- quantile(sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[3,],probs=c(0.25,0.75))
  alpha_g.50[,8] <- quantile(sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[3,],probs=c(0.25,0.75))
  alpha_g.50[,9] <- quantile(sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[3,],probs=c(0.25,0.75))
  alpha_g.50[,11] <- quantile(unlist(sapply(fit[2,],"[[","SH2")["alpha",]),probs=c(0.25,0.75))
  alpha_g.50[,13] <- quantile(unlist(sapply(fit[2,],"[[","SH4")["alpha",]),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=alpha_g.m,q25=alpha_g.50[1,],q75=alpha_g.50[2,],
                                      syndrome="mixed-pollination",models=levels(models),param="alpha"))
  
  
  half_g.m <- numeric(13)
  names(half_g.m) <- levels(models)
  half_g.m[c(1:4,10,12)] <- NA
  half_g.m[5] <- median(log(2)/unlist(sapply(fit[2,],"[[","OU1")["alpha",]))
  half_g.m[6] <- median(log(2)/unlist(sapply(fit[2,],"[[","OUM")["alpha",]))
  half_g.m[7] <- median(log(2)/sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[3,])
  half_g.m[8] <- median(log(2)/sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[3,])
  half_g.m[9] <- median(log(2)/sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[3,])
  half_g.m[11] <- median(log(2)/unlist(sapply(fit[2,],"[[","SH2")["alpha",]))
  half_g.m[13] <- median(log(2)/unlist(sapply(fit[2,],"[[","SH4")["alpha",]))
  
  half_g.50 <- matrix(ncol=13,nrow=2)
  colnames(half_g.50) <- levels(models)
  half_g.50[,5] <- quantile(log(2)/unlist(sapply(fit[2,],"[[","OU1")["alpha",]),probs=c(0.25,0.75))
  half_g.50[,6] <- quantile(log(2)/unlist(sapply(fit[2,],"[[","OUM")["alpha",]),probs=c(0.25,0.75))
  half_g.50[,7] <- quantile(log(2)/sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[3,],probs=c(0.25,0.75))
  half_g.50[,8] <- quantile(log(2)/sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[3,],probs=c(0.25,0.75))
  half_g.50[,9] <- quantile(log(2)/sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[3,],probs=c(0.25,0.75))
  half_g.50[,11] <- quantile(log(2)/unlist(sapply(fit[2,],"[[","SH2")["alpha",]),probs=c(0.25,0.75))
  half_g.50[,13] <- quantile(log(2)/unlist(sapply(fit[2,],"[[","SH4")["alpha",]),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=half_g.m,q25=half_g.50[1,],q75=half_g.50[2,],
                                      syndrome="mixed-pollination",models=levels(models),param="half-life"))
  
  station_g.m <- numeric(13)
  names(station_g.m) <- levels(models)
  station_g.m[c(1:4,10,12)] <- NA
  station_g.m[5] <- median(sapply(lapply(fit[2,],"[[","OU1"),stationary))
  station_g.m[6] <- median(sapply(lapply(fit[2,],"[[","OUM"),stationary))
  station_g.m[7] <- median((sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[3,])))
  station_g.m[8] <- median((sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[3,])))
  station_g.m[9] <- median((sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[3,])))
  station_g.m[11] <- median(sapply(lapply(fit[2,],"[[","SH2"),stationary))
  station_g.m[13] <- median(sapply(lapply(fit[2,],"[[","SH4"),stationary))
  
  station_g.50 <- matrix(ncol=13,nrow=2)
  colnames(station_g.50) <- levels(models)
  station_g.50[,5] <- quantile(sapply(lapply(fit[2,],"[[","OU1"),stationary),probs=c(0.25,0.75))
  station_g.50[,6] <- quantile(sapply(lapply(fit[2,],"[[","OUM"),stationary),probs=c(0.25,0.75))
  station_g.50[,7] <- quantile((sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMV")["solution",],as.vector)[3,])),probs=c(0.25,0.75))
  station_g.50[,8] <- quantile((sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMA")["solution",],as.vector)[3,])),probs=c(0.25,0.75))
  station_g.50[,9] <- quantile((sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[4,]/(2*sapply(sapply(fit[2,],"[[","OUMVA")["solution",],as.vector)[3,])),probs=c(0.25,0.75))
  station_g.50[,11] <- quantile(sapply(lapply(fit[2,],"[[","SH2"),stationary),probs=c(0.25,0.75))
  station_g.50[,13] <- quantile(sapply(lapply(fit[2,],"[[","SH4"),stationary),probs=c(0.25,0.75))
  
  fig.dat <- rbind(fig.dat,data.frame(value=station_g.m,q25=station_g.50[1,],q75=station_g.50[2,],
                                      syndrome="mixed-pollination",models=levels(models),param="stationary variance"))
  
  med.results <- data.frame(logLik=logLik.m, param=nparam[,1], AICc=aicc.m, 
                            theta.h=theta_h.m, theta.g=theta_g.m,
                            sigma.h=sigma_h.m, sigma.g=sigma_g.m,
                            station.h=station_h.m, station.g=station_g.m)
  results.print <- data.frame(models=levels(models),
                              logLik=paste(round(logLik.m,1)," [",round(logLik.50[1,],1),",",round(logLik.50[2,],1),"]",sep=""), 
                              param=round(nparam[,1],0), 
                              AICc=paste(round(aicc.m,1)," [",round(aicc.50[1,],1),",",round(aicc.50[2,],1),"]",sep=""),
                              AICcw=paste(round(aiccw.m,2)," [",round(aiccw.50[1,],2),",",round(aiccw.50[2,],2),"]",sep=""),
                              theta.h=paste(round(theta_h.m,3)," [",round(theta_h.50[1,],3),",",round(theta_h.50[2,],3),"]",sep=""),
                              theta.g=paste(round(theta_g.m,3)," [",round(theta_g.50[1,],3),",",round(theta_g.50[2,],3),"]",sep=""),
                              sigma.h=paste(round(sigma_h.m,3)," [",round(sigma_h.50[1,],3),",",round(sigma_h.50[2,],3),"]",sep=""),
                              sigma.g=paste(round(sigma_g.m,3)," [",round(sigma_g.50[1,],3),",",round(sigma_g.50[2,],3),"]",sep=""),
                              half.time.h=paste(round(half_h.m,3)," [",round(half_h.50[1,],3),",",round(half_h.50[2,],3),"]",sep=""),
                              half.time.g=paste(round(half_g.m,3)," [",round(half_g.50[1,],3),",",round(half_g.50[2,],3),"]",sep=""),
                              station.h=paste(round(station_h.m,3)," [",round(station_h.50[1,],3),",",round(station_h.50[2,],3),"]",sep=""),
                              station.g=paste(round(station_g.m,3)," [",round(station_g.50[1,],3),",",round(station_g.50[2,],3),"]",sep=""))
  print(results.print)
  invisible(list(table=results.print,fig=fig.dat))
}


####
# PC1

library(parallel)
set.seed(1234)
nsim=100
PC=1
chartrees <- make.simmap(random.trees[1:nsim], pollinator.data, model="ER", nsim = 1)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="univar_pc1_out.txt") # Initiate cluster
fit_pc1 <- parSapply(cl,chartrees,function(x) UniModelsFit(x, res.tan.spe[,PC],pollinator.data,error=sd.error[,PC]))
stopCluster(cl)

# save(fit_pc1,file="./cluster/univar_pc1_conf.RData")
# load("./cluster/univar_pc1_conf.RData")
# load("./cluster/univar_pc1_allsp.RData")
fit <- fit_pc1

# Convert results to summary tables
models=factor(c("OU1","OUM","OUMV","OUMA","OUMVA","BM1","BMV","BM1m","BMVm","OUBMr","BMOUr","OUBM","BMOU"),
              levels=c("BM1","BMV","BM1m","BMVm","OU1","OUM","OUMV","OUMA","OUMVA","OUBMr","BMOUr","OUBM","BMOU"))
w.res.fit <- data.frame(weights=c(sapply(fit[1,],"[[","aiccw")),models=models)
aic.res.fit <- data.frame(aic=c(sapply(fit[1,],"[[","AICc")),models=models)

library(xtable)
res.pc1 <- param.table.univar(fit,precision=2)
xtable(res.pc1$table[,c(-2,-4,-10,-11)], digits=0)
res.pc1$fig$PC <- "PC1"


####
# PC2

set.seed(1234)
nsim=100
PC=2
chartrees <- make.simmap(random.trees[1:nsim], pollinator.data, model="ER", nsim = 1)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="univar_pc2_out.txt") # Initiate cluster
fit_pc2 <- parSapply(cl,chartrees,function(x) UniModelsFit(x, res.tan.spe[,PC],pollinator.data,error=sd.error[,PC]))
stopCluster(cl)

# save(chartrees,fit_pc2,file="./cluster/univar_pc2_conf.RData")
# load("./cluster/univar_pc2_conf.RData")
# load("./cluster/univar_pc2_allsp.RData")
fit <- fit_pc2

# Convert results to summary tables
w.res.fit <- data.frame(weights=c(sapply(fit[1,],"[[","aiccw")),models=models)
aic.res.fit <- data.frame(aic=c(sapply(fit[1,],"[[","AICc")),models=models)

# parameter values
res.pc2 <- param.table.univar(fit,precision=2)
xtable(res.pc2$table[,c(-2,-4,-10,-11)], digits=0)
res.pc2$fig$PC <- "PC2"


####
# PC3

set.seed(1234)
nsim=100
PC=3
chartrees <- make.simmap(random.trees[1:nsim], pollinator.data, model="ER", nsim = 1)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="univar_pc3_out.txt") # Initiate cluster
fit_pc3 <- parSapply(cl,chartrees,function(x) UniModelsFit(x, res.tan.spe[,PC],pollinator.data,error=sd.error[,PC]))
stopCluster(cl)

# save(fit_pc3,file="./cluster/univar_pc3_conf.RData")
# load("./cluster/univar_pc3_conf.RData")
# load("./cluster/univar_pc3_allsp.RData")
fit <- fit_pc3

# Convert results to summary tables
w.res.fit <- data.frame(weights=c(sapply(fit[1,],"[[","aiccw")),models=models)
aic.res.fit <- data.frame(aic=c(sapply(fit[1,],"[[","AICc")),models=models)

# parameter values
res.pc3 <- param.table.univar(fit,precision=2)
xtable(res.pc3$table[,c(-2,-4,-10,-11)], digits=0)
res.pc3$fig$PC <- "PC3"


# Multivariate -----

# Open trees
random.trees <- read.nexus("FiveThousandTrees.trees")

# Change species names to fit that of the table
attr(random.trees,"TipLabel") <- sub("G","GES_",random.trees$tip.label$tip.label)
attr(random.trees,"TipLabel") <- sub("R","RHY_",random.trees$tip.label$tip.label)

###
# For cluster analysis
#
# save(random.trees,data,res.pca,file="multivar_cluster.RData")
# require(ape)
# require(phytools)
# require(mvMORPH)
# require(OUwie)
# require(parallel)
# require(ggplot2)
# load("./cluster/univar_cluster.RData")

# To filter the taxa, use one of the following blocks

# 1: Remove species for which we don't have data
# exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
# exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
# exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
# exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3))
# random.trees<-lapply(random.trees,drop.tip,tip=exclude)
# class(random.trees)<-"multiPhylo"
# attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

# 2: Use only confirmed species
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
exclude.nodata4 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Confirmed"]=="no","CodeSpecies"])]
exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3,exclude.nodata4))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

# 3: Use only confirmed species - with bats
# exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
# exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
# exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth"),"CodeSpecies"])]
# exclude.nodata4 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Confirmed"]=="no","CodeSpecies"])]
# exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3,exclude.nodata4))
# random.trees<-lapply(random.trees,drop.tip,tip=exclude)
# class(random.trees)<-"multiPhylo"
# attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label


# Order data according to tree tips
# Calculate mean PC coordinates per species
species <- unique(data[,'CodeSpecies'])
res.tan.spe<-matrix(data=NA,nrow=length(species),ncol=64)
for (i in 1:length(species)){
  if(length(data[data[,'CodeSpecies']==species[i],1])==1) {
    res.tan.spe[i,]<-res.pca$x[data[,'CodeSpecies']==species[i],]
  }
  else 
    res.tan.spe[i,]<-apply(res.pca$x[data[,'CodeSpecies']==species[i],],2,mean)
}
rownames(res.tan.spe) <- species
res.tan.spe <- res.tan.spe[match(attr(random.trees,"TipLabel"),rownames(res.tan.spe)),]
colnames(res.tan.spe) = sapply(1:ncol(res.tan.spe),function(c) paste("PC",c,sep=""))

# Vector of pollinator data
#Read syndrome data
syndata <- read.csv("species.csv", sep=";", header=TRUE)
syndata <- syndata[,c(1,4:5)]
rownames(syndata) <- syndata[,'CodeSpecies']
#Reorder data frame
syndata <- syndata[match(attr(random.trees,"TipLabel"),rownames(syndata)),]
#Vector of pollinator data
pollinator.data <- as.factor(as.vector(syndata$Pollinator))
names(pollinator.data) <- syndata[,'CodeSpecies']


###
# Calculate intraspecific standard error to include 
# as error term in model fitting

data.spe.gen <- res.tan.spe[pollinator.data == "mixed-pollination",1:3]
data.ind.gen <- res.pca$x[data$Pollinator == "mixed-pollination",1:3]
rownames(data.ind.gen) <- data$CodeSpecies[data$Pollinator == "mixed-pollination"]
sd.error.gen <- matrix(nrow=nrow(data.spe.gen),ncol=3)
rownames(sd.error.gen) <- rownames(data.spe.gen)
colnames(sd.error.gen) <- colnames(data.spe.gen)
for (i in 1:nrow(sd.error.gen)) {
  temp <- data.ind.gen[rownames(data.ind.gen) == rownames(data.spe.gen)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.gen[i,1] <- sd.error.gen[i,2] <- sd.error.gen[i,3] <- NA
    next
  }
  sd.error.gen[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.gen[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                          
  sd.error.gen[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                          
}
gen.error <- mean(sd.error.gen, na.rm=TRUE)
# Replace NAs by mean
sd.error.gen[is.na(sd.error.gen)] <- gen.error

# Hummingbird specialists
data.spe.hum <- res.tan.spe[pollinator.data == "hummingbird",1:3]
data.ind.hum <- res.pca$x[data$Pollinator == "hummingbird",1:3]
rownames(data.ind.hum) <- data$CodeSpecies[data$Pollinator == "hummingbird"]
sd.error.hum <- matrix(nrow=nrow(data.spe.hum),ncol=3)
rownames(sd.error.hum) <- rownames(data.spe.hum)
colnames(sd.error.hum) <- colnames(data.spe.hum)
for (i in 1:nrow(sd.error.hum)) {
  temp <- data.ind.hum[rownames(data.ind.hum) == rownames(data.spe.hum)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.hum[i,1] <- sd.error.hum[i,2] <- sd.error.hum[i,3] <- NA
    next
  }
  sd.error.hum[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.hum[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                           
  sd.error.hum[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                           
}
hum.error <- mean(sd.error.hum, na.rm=TRUE)
# Replace NAs by mean
sd.error.hum[is.na(sd.error.hum)] <- hum.error

# bat specialists
# data.spe.bat <- res.tan.spe[pollinator.data == "bat",1:3]
# data.ind.bat <- res.pca$x[data$Pollinator == "bat",1:3]
# rownames(data.ind.bat) <- data$CodeSpecies[data$Pollinator == "bat"]
# sd.error.bat <- matrix(nrow=nrow(data.spe.bat),ncol=3)
# rownames(sd.error.bat) <- rownames(data.spe.bat)
# colnames(sd.error.bat) <- colnames(data.spe.bat)
# for (i in 1:nrow(sd.error.bat)) {
#   temp <- data.ind.bat[rownames(data.ind.bat) == rownames(data.spe.bat)[i],]
#   if (length(as.vector(temp))==3) {
#     sd.error.bat[i,1] <- sd.error.bat[i,2] <- sd.error.bat[i,3] <- NA
#     next
#   }
#   sd.error.bat[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
#   sd.error.bat[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                           
#   sd.error.bat[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                           
# }
# bat.error <- mean(sd.error.bat, na.rm=TRUE)
# # Replace NAs by mean
# sd.error.bat[is.na(sd.error.bat)] <- bat.error
# sd.error <- rbind(sd.error.hum,sd.error.gen,sd.error.bat)

# Combine error matrices
sd.error <- rbind(sd.error.hum,sd.error.gen)
sd.error <- sd.error[attr(random.trees,"TipLabel"),]

###
# Functionto fitmultivariate models

MultiModelsFit <- function(tree, trait, states, error=NULL, ...){
  require(mvMORPH)
  # tree is a mapped simmap tree
  # trait is a named vector of continuous values
  # states is a named vector of regime states
  # error is a named matrix of standard errors
  # ... options are:
  # scaleHeight=TRUE, the default
  # root.station=TRUE, the default
  
  # Options
  par <- list(...)
  if(is.null(par[["root.station"]])){
    rootmvMORPH <- "stationary"
    rootOUwie <- TRUE
  }else{
    rootmvMORPH <- FALSE
    rootOUwie <- FALSE
  }
  
  if(is.null(par[["scaleHeight"]])){
    scaleHeight <- TRUE
  }else{
    scaleHeight <- FALSE  
  }
  
  # check data
  if(is.null(rownames(trait))) stop("trait vector must be named")
  if(is.null(names(states))) stop("states vector must be named")
  if(is.null(rownames(error))) stop("error matrix must be named")
  if(!inherits(tree,"simmap")) stop("tree should be an object of class \"simmap\".")
  
  # ---- mvMORPH models
  errorsq <- error
  if(!is.null(errorsq)) errorsq=errorsq^2
  # BM1 model
  BM1 <- mvBM(tree, trait, error=errorsq, model="BM1", 
              method="sparse", scale.height=scaleHeight,
              diagnostic=FALSE, echo=FALSE)
  # BMM model
  BMM <- mvBM(tree, trait, error=errorsq, model="BMM", 
              method="sparse", scale.height=scaleHeight,
              diagnostic=FALSE, echo=FALSE)
  # BM1nc model, multiple phylogenetic means
  BM1nc <- mvBM(tree, trait, error=errorsq, model="BM1", 
                method="sparse", param=list(smean=FALSE), 
                scale.height=scaleHeight, diagnostic=FALSE, echo=FALSE)
  # BMMnc model, multiple phylogenetic means
  BMMnc <- mvBM(tree, trait, error=errorsq, model="BMM", 
                method="sparse", param=list(smean=FALSE), 
                scale.height=scaleHeight, diagnostic=FALSE, echo=FALSE)
  # OU1
  OU1 <- mvOU(tree, trait, error=errorsq, model="OU1", 
              method="sparse", scale.height=scaleHeight,
              diagnostic=FALSE, echo=FALSE)
  # OUM
  OUM <- mvOU(tree, trait, error=errorsq, model="OUM", 
              method="sparse", scale.height=scaleHeight, param=list(vcv="fixedRoot"),
              diagnostic=FALSE, echo=FALSE)
  
  # SHIFT model
  if(ncol(tree$mapped.edge)==2){
    
    # OUBM model
    OUBM <- mvSHIFT(tree, trait, error=errorsq, model="OUBM",
                    method="sparse", param=list(smean=FALSE),
                    scale.height=scaleHeight,
                    diagnostic=FALSE, echo=FALSE)  
    
    BMOU <- mvSHIFT(tree, trait, error=errorsq, model="BMOU",
                    method="sparse", param=list(smean=FALSE),
                    scale.height=scaleHeight,
                    diagnostic=FALSE, echo=FALSE)   
    
    # OUBMr model
    OUBMr <- mvSHIFT(tree, trait, error=errorsq, model="OUBMi",
                     method="sparse", param=list(smean=FALSE),
                     scale.height=scaleHeight,
                     diagnostic=FALSE, echo=FALSE)  
    
    BMOUr <- mvSHIFT(tree, trait, error=errorsq, model="BMOUi",
                     method="sparse", param=list(smean=FALSE),
                     scale.height=scaleHeight,
                     diagnostic=FALSE, echo=FALSE)   
    
    # Results table
    resultsFit <- data.frame(models=c("BM1","BMM","BM1nc","BMMnc","OU1","OUM","OUBM","BMOU","OUBMr","BMOUr"),
                             logLik=c(BM1$LogLik,BMM$LogLik,BM1nc$LogLik,BMMnc$LogLik,OU1$LogLik,OUM$LogLik,OUBM$LogLik,BMOU$LogLik,OUBMr$LogLik,BMOUr$LogLik),
                             nparam=c(BM1$param$nparam,BMM$param$nparam,BM1nc$param$nparam,BMMnc$param$nparam,OU1$param$nparam,OUM$param$nparam,OUBM$param$nparam,BMOU$param$nparam,OUBMr$param$nparam,BMOUr$param$nparam),
                             convergence=c(BM1$convergence==0,BMM$convergence==0,BM1nc$convergence==0,BMMnc$convergence==0,OU1$convergence==0,OUM$convergence==0,OUBM$convergence==0,BMOU$convergence==0,OUBMr$convergence==0,BMOUr$convergence==0),
                             AIC=c(BM1$AIC,BMM$AIC,BM1nc$AIC,BMMnc$AIC,OU1$AIC,OUM$AIC,OUBM$AIC,BMOU$AIC,OUBMr$AIC,BMOUr$AIC),
                             AICc=c(BM1$AICc,BMM$AICc,BM1nc$AICc,BMMnc$AICc,OU1$AICc,OUM$AICc,OUBM$AICc,BMOU$AICc,OUBMr$AICc,BMOUr$AICc))
    #resultsFit$AICc <- resultsFit$AIC+((2*resultsFit$nparam*(resultsFit$nparam+1))/((nrow(trait)*ncol(trait))-resultsFit$nparam-1))
    resultsFit$AICdelta <- resultsFit$AIC-min(resultsFit$AIC)
    resultsFit$AICcdelta <- resultsFit$AICc-min(resultsFit$AICc)
    resultsFit$aicw <- exp(-0.5*resultsFit$AICdelta) / sum(exp(-0.5*resultsFit$AICdelta))
    resultsFit$aiccw <- exp(-0.5*resultsFit$AICcdelta) / sum(exp(-0.5*resultsFit$AICcdelta))
    
    listFit <- list(BM1=BM1, BMM=BMM, BM1nc=BM1nc, BMMnc=BMMnc, OU1=OU1, OUM=OUM, OUBM=OUBM, BMOU=BMOU, OUBMr=OUBMr, BMOUr=BMOUr)
    
  }else{
    # Results table
    resultsFit <- data.frame(models=c("BM1","BMM","BM1nc","BMMnc","OU1","OUM"),
                             logLik=c(BM1$LogLik,BMM$LogLik,BM1nc$LogLik,BMMnc$LogLik,OU1$LogLik,OUM$LogLik),
                             nparam=c(BM1$param$nparam,BMM$param$nparam,BM1nc$param$nparam,BMMnc$param$nparam,OU1$param$nparam,OUM$param$nparam),
                             convergence=c(BM1$convergence==0,BMM$convergence==0,BM1nc$convergence==0,BMMnc$convergence==0,OU1$convergence==0,OUM$convergence==0),
                             AIC=c(BM1$AIC,BMM$AIC,BM1nc$AIC,BMMnc$AIC,OU1$AIC,OUM$AIC),
                             AICc=c(BM1$AICc,BMM$AICc,BM1nc$AICc,BMMnc$AICc,OU1$AICc,OUM$AICc))
    #resultsFit$AICc <- resultsFit$AIC+((2*resultsFit$nparam*(resultsFit$nparam+1))/((nrow(trait)*ncol(trait))-resultsFit$nparam-1))
    resultsFit$AICdelta <- resultsFit$AIC-min(resultsFit$AIC)
    resultsFit$AICcdelta <- resultsFit$AICc-min(resultsFit$AICc)
    resultsFit$aicw <- exp(-0.5*resultsFit$AICdelta) / sum(exp(-0.5*resultsFit$AICdelta))
    resultsFit$aiccw <- exp(-0.5*resultsFit$AICcdelta) / sum(exp(-0.5*resultsFit$AICcdelta))
    
    listFit <- list(BM1=BM1, BMM=BMM, BM1nc=BM1nc, BMMnc=BMMnc, OU1=OU1, OUM=OUM)
  }
  
  #print(resultsFit)
  # Return the results
  results <- list(fit=resultsFit, models=listFit)
  invisible(results)
}

# Parallel execution
set.seed(1234)
nsim=3
PC=1:3
chartrees <- make.simmap(random.trees[1:nsim], pollinator.data,model="ER", nsim = 1)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="multivar.txt") # Initiate cluster
multi.fit <- parSapply(cl,chartrees,function(x) MultiModelsFit(x, res.tan.spe[,PC],pollinator.data,error=sd.error[,PC]))
stopCluster(cl)

# save(multi.fit, file="multi_conf.RData")
# load(file="./cluster/multi_allsp.RData")
# load(file="./cluster/multi_conf.RData")
fit <- multi.fit

# Convert results to summary tables
models=factor(c("BM1","BMV","BM1m","BMVm","OU1","OUM","OUBM","BMOU","OUBMr","BMOUr"),
              levels=c("BM1","BMV","BM1m","BMVm","OU1","OUM","OUBM","BMOU","OUBMr","BMOUr"))
res.fit <- data.frame(weights=c(sapply(fit[1,],"[[","aiccw")),aic=c(sapply(fit[1,],"[[","AICc")),models=models)


# Extract paramter estimates

models=factor(c("BM1","BMV","BM1m","BMVm","OU1","OUM","OUBM","BMOU","OUBMr","BMOUr"),
              levels=c("BM1","BMV","BM1m","BMVm","OU1","OUM","OUBM","BMOU","OUBMr","BMOUr"))

# remove replicates with non convergence
fit <- fit[,apply(sapply(fit[1,],"[[","convergence"),2,function(x) all(x==TRUE))]

logLik <- data.frame(logLik=c(sapply(fit[1,],"[[","logLik")),models=models)
logLik.m <- apply(unstack(logLik,select=models),2,mean)
logLik.sd <- apply(unstack(logLik,select=models),2,sd)
logLik.50 <- apply(unstack(logLik,select=models),2,function(c) quantile(c,probs=c(0.25,0.75)))
nparam <- data.frame(nparam=c(sapply(fit[1,1],"[[","nparam")),models=models)
nparam <- nparam[match(levels(models),nparam$models),]
aicc <- data.frame(aic=c(sapply(fit[1,],"[[","AICc")),models=models)
aicc.m <- apply(unstack(aicc,select=models),2,mean)
aicc.sd <- apply(unstack(aicc,select=models),2,sd)
aicc.50 <- apply(unstack(aicc,select=models),2,function(c) quantile(c,probs=c(0.25,0.75)))
aicc.vals <- sapply(fit[1,],"[[","AICc")
aicc.delta <- sapply(c(1:ncol(aicc.vals)), function(x) aicc.vals[,x]-min(aicc.vals[,x]))
aiccw <- sapply(c(1:ncol(aicc.vals)), function(x) exp(-0.5*aicc.delta[,x]) / sum(exp(-0.5*aicc.delta[,x])))
rownames(aiccw) <- models
aiccw <- aiccw[levels(models),]
aiccw.m <- apply(aiccw,1,mean)
aiccw.sd <- apply(aiccw,1,sd)
aiccw.50 <- apply(aiccw,1,function(c) quantile(c,probs=c(0.25,0.75)))

(med.results <- data.frame(models=levels(models),
                           logLik=paste(round(logLik.m,2)," [",round(logLik.50[1,],2),",",round(logLik.50[2,],2),"]",sep=""), 
                           param=nparam[,1], 
                           AICc=paste(round(aicc.m,2)," [",round(aicc.50[1,],2),",",round(aicc.50[2,],2),"]",sep=""),
                           AICcw=paste(round(aiccw.m,2)," [",round(aiccw.50[1,],2),",",round(aiccw.50[2,],2),"]",sep="")))
library(xtable)
xtable(med.results[,-4], digits=0)

# Extract parameter values for all models

theta_h.m <- matrix(ncol=3,nrow=length(models))
rownames(theta_h.m) <- levels(models)
colnames(theta_h.m) <- c("PC1","PC2","PC3")
theta_h.m[1,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_h.m[2,] <- apply(array(unlist(sapply(fit[2,],"[[","BMM")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_h.m[3,] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],function(x) c(t(x))),1,median)[1:3]
theta_h.m[4,] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],function(x) c(t(x))),1,median)[1:3]
theta_h.m[5,] <- apply(array(unlist(sapply(fit[2,],"[[","OU1")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_h.m[6,] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],function(x) c(t(x))),1,median)[1:3]
theta_h.m[7,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBM")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_h.m[8,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOU")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_h.m[9,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBMr")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_h.m[10,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOUr")["theta",]),dim=c(3,dim(fit)[2])),1,median)

theta_h.sd <- matrix(ncol=3,nrow=length(models))
rownames(theta_h.sd) <- levels(models)
colnames(theta_h.sd) <- c("PC1","PC2","PC3")
theta_h.sd[1,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_h.sd[2,] <- apply(array(unlist(sapply(fit[2,],"[[","BMM")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_h.sd[3,] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],function(x) c(t(x))),1,sd)[1:3]
theta_h.sd[4,] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],function(x) c(t(x))),1,sd)[1:3]
theta_h.sd[5,] <- apply(array(unlist(sapply(fit[2,],"[[","OU1")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_h.sd[6,] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],function(x) c(t(x))),1,sd)[1:3]
theta_h.sd[7,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBM")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_h.sd[8,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOU")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_h.sd[9,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBMr")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_h.sd[10,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOUr")["theta",]),dim=c(3,dim(fit)[2])),1,sd)

theta_h.50 <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],function(x) c(t(x))),1,function(c) quantile(c, probs = c(0.25,0.75)))[,1:3]

sigma_h.m <- matrix(ncol=9,nrow=length(models))
rownames(sigma_h.m) <- levels(models)
sigma_h.m[1,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[2,] <- apply(array(unlist(sapply(fit[2,],"[[","BMM")["sigma",])[1:9],dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[3,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[4,] <- apply(array(unlist(sapply(fit[2,],"[[","BMMnc")["sigma",])[1:9],dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[5,] <- apply(array(unlist(sapply(fit[2,],"[[","OU1")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[6,] <- apply(array(unlist(sapply(fit[2,],"[[","OUM")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[7,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBM")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[8,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOU")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[9,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBMr")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_h.m[10,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOUr")["sig",]),dim=c(9,dim(fit)[2])),1,median)

sigma_h.sd <- matrix(ncol=9,nrow=length(models))
rownames(sigma_h.sd) <- levels(models)
sigma_h.sd[1,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[2,] <- apply(array(unlist(sapply(fit[2,],"[[","BMM")["sigma",])[1:9],dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[3,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[4,] <- apply(array(unlist(sapply(fit[2,],"[[","BMMnc")["sigma",])[1:9],dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[5,] <- apply(array(unlist(sapply(fit[2,],"[[","OU1")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[6,] <- apply(array(unlist(sapply(fit[2,],"[[","OUM")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[7,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBM")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[8,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOU")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[9,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBMr")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_h.sd[10,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOUr")["sig",]),dim=c(9,dim(fit)[2])),1,sd)

sigma_h.50 <- apply(array(unlist(sapply(fit[2,],"[[","OUM")["sigma",]),dim=c(9,dim(fit)[2])),1,function(c) quantile(c,probs=c(0.25,0.75)))[,c(1,5,9)]

station_h.m <- matrix(ncol=9,nrow=length(models))
rownames(station_h.m) <- levels(models)
station_h.m[c(1:4,8,10)] <- NA
station_h.m[5,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OU1"),stationary)),dim=c(9,dim(fit)[2])),1,median)
station_h.m[6,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),stationary)),dim=c(9,dim(fit)[2])),1,median)
station_h.m[7,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUBM"),stationary)),dim=c(9,dim(fit)[2])),1,median)
station_h.m[9,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUBMr"),stationary)),dim=c(9,dim(fit)[2])),1,median)

station_h.sd <- matrix(ncol=9,nrow=length(models))
rownames(station_h.sd) <- levels(models)
station_h.sd[c(1:4,8,10)] <- NA
station_h.sd[5,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OU1"),stationary)),dim=c(9,dim(fit)[2])),1,sd)
station_h.sd[6,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),stationary)),dim=c(9,dim(fit)[2])),1,sd)
station_h.sd[7,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUBM"),stationary)),dim=c(9,dim(fit)[2])),1,sd)
station_h.sd[9,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUBMr"),stationary)),dim=c(9,dim(fit)[2])),1,sd)

station_h.50 <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),stationary)),dim=c(9,dim(fit)[2])),1,function(c) quantile(c,probs=c(0.25,0.75)))[,c(1,5,9)]
station_h.50 <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),stationary)),dim=c(9,dim(fit)[2])),1,function(c) quantile(c,probs=c(0.25,0.75)))


halftime_h.m <- matrix(ncol=3,nrow=length(models))
rownames(halftime_h.m) <- levels(models)
halftime_h.m[c(1:4,7:10)] <- NA
halftime_h.m[5,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OU1"),halflife)),dim=c(3,dim(fit)[2])),1,median)
halftime_h.m[6,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),halflife)),dim=c(3,dim(fit)[2])),1,median)

halftime_h.sd <- matrix(ncol=3,nrow=length(models))
rownames(halftime_h.sd) <- levels(models)
halftime_h.sd[c(1:4,7:10)] <- NA
halftime_h.sd[5,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OU1"),halflife)),dim=c(3,dim(fit)[2])),1,sd)
halftime_h.sd[6,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),halflife)),dim=c(3,dim(fit)[2])),1,sd)

halftime_h.50 <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),halflife)),dim=c(3,dim(fit)[2])),1,function(c) quantile(c,probs=c(0.25,0.75)))

theta_g.m <- matrix(ncol=3,nrow=length(models))
rownames(theta_g.m) <- levels(models)
colnames(theta_g.m) <- c("PC1","PC2","PC3")
theta_g.m[1,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_g.m[2,] <- apply(array(unlist(sapply(fit[2,],"[[","BMM")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_g.m[3,] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],function(x) c(t(x))),1,median)[4:6]
theta_g.m[4,] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],function(x) c(t(x))),1,median)[4:6]
theta_g.m[5,] <- apply(array(unlist(sapply(fit[2,],"[[","OU1")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_g.m[6,] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],function(x) c(t(x))),1,median)[4:6]
theta_g.m[7,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBM")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_g.m[8,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOU")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_g.m[9,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBMr")["theta",]),dim=c(3,dim(fit)[2])),1,median)
theta_g.m[10,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOUr")["theta",]),dim=c(3,dim(fit)[2])),1,median)

theta_g.sd <- matrix(ncol=3,nrow=length(models))
rownames(theta_g.sd) <- levels(models)
colnames(theta_g.sd) <- c("PC1","PC2","PC3")
theta_g.sd[1,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_g.sd[2,] <- apply(array(unlist(sapply(fit[2,],"[[","BMM")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_g.sd[3,] <- apply(sapply(sapply(fit[2,],"[[","BM1nc")["theta",],function(x) c(t(x))),1,sd)[4:6]
theta_g.sd[4,] <- apply(sapply(sapply(fit[2,],"[[","BMMnc")["theta",],function(x) c(t(x))),1,sd)[4:6]
theta_g.sd[5,] <- apply(array(unlist(sapply(fit[2,],"[[","OU1")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_g.sd[6,] <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],function(x) c(t(x))),1,sd)[4:6]
theta_g.sd[7,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBM")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_g.sd[8,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOU")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_g.sd[9,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBMr")["theta",]),dim=c(3,dim(fit)[2])),1,sd)
theta_g.sd[10,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOUr")["theta",]),dim=c(3,dim(fit)[2])),1,sd)

theta_g.50 <- apply(sapply(sapply(fit[2,],"[[","OUM")["theta",],function(x) c(t(x))),1,function(c) quantile(c, probs = c(0.25,0.75)))[,4:6]

sigma_g.m <- matrix(ncol=9,nrow=length(models))
rownames(sigma_g.m) <- levels(models)
sigma_g.m[1,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[2,] <- apply(array(unlist(sapply(fit[2,],"[[","BMM")["sigma",])[10:18],dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[3,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[4,] <- apply(array(unlist(sapply(fit[2,],"[[","BMMnc")["sigma",])[10:18],dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[5,] <- apply(array(unlist(sapply(fit[2,],"[[","OU1")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[6,] <- apply(array(unlist(sapply(fit[2,],"[[","OUM")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[7,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBM")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[8,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOU")["sigma",]),dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[9,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBMr")["sig",]),dim=c(9,dim(fit)[2])),1,median)
sigma_g.m[10,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOUr")["sigma",]),dim=c(9,dim(fit)[2])),1,median)

sigma_g.sd <- matrix(ncol=9,nrow=length(models))
rownames(sigma_g.sd) <- levels(models)
sigma_g.sd[1,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[2,] <- apply(array(unlist(sapply(fit[2,],"[[","BMM")["sigma",])[10:18],dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[3,] <- apply(array(unlist(sapply(fit[2,],"[[","BM1nc")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[4,] <- apply(array(unlist(sapply(fit[2,],"[[","BMMnc")["sigma",])[10:18],dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[5,] <- apply(array(unlist(sapply(fit[2,],"[[","OU1")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[6,] <- apply(array(unlist(sapply(fit[2,],"[[","OUM")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[7,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBM")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[8,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOU")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[9,] <- apply(array(unlist(sapply(fit[2,],"[[","OUBMr")["sig",]),dim=c(9,dim(fit)[2])),1,sd)
sigma_g.sd[10,] <- apply(array(unlist(sapply(fit[2,],"[[","BMOUr")["sigma",]),dim=c(9,dim(fit)[2])),1,sd)

sigma_g.50 <- apply(array(unlist(sapply(fit[2,1],"[[","OUM")["sigma",]),dim=c(9,dim(fit)[2])),1,function(c) quantile(c,probs=c(0.25,0.75)))[,c(1,5,9)]

halftime_g.m <- matrix(ncol=3,nrow=length(models))
rownames(halftime_g.m) <- levels(models)
halftime_g.m[c(1:4,7:10)] <- NA
halftime_g.m[5,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OU1"),halflife)),dim=c(3,dim(fit)[2])),1,median)
halftime_g.m[6,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),halflife)),dim=c(3,dim(fit)[2])),1,median)

halftime_g.sd <- matrix(ncol=3,nrow=length(models))
rownames(halftime_g.sd) <- levels(models)
halftime_g.sd[c(1:4,7:10)] <- NA
halftime_g.sd[5,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OU1"),halflife)),dim=c(3,dim(fit)[2])),1,sd)
halftime_g.sd[6,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),halflife)),dim=c(3,dim(fit)[2])),1,sd)

station_g.m <- matrix(ncol=9,nrow=length(models))
rownames(station_g.m) <- levels(models)
station_g.m[c(1:4,8,10)] <- NA
station_g.m[5,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OU1"),stationary)),dim=c(9,dim(fit)[2])),1,median)
station_g.m[6,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),stationary)),dim=c(9,dim(fit)[2])),1,median)
station_g.m[7,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUBM"),stationary)),dim=c(9,dim(fit)[2])),1,median)
station_g.m[9,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUBMr"),stationary)),dim=c(9,dim(fit)[2])),1,median)

station_g.sd <- matrix(ncol=9,nrow=length(models))
rownames(station_g.sd) <- levels(models)
station_g.sd[c(1:4,7,9)] <- NA
station_g.sd[5,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OU1"),stationary)),dim=c(9,dim(fit)[2])),1,sd)
station_g.sd[6,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","OUM"),stationary)),dim=c(9,dim(fit)[2])),1,sd)
station_g.sd[8,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","BMOU"),stationary)),dim=c(9,dim(fit)[2])),1,sd)
station_g.sd[10,] <- apply(array(unlist(lapply(lapply(fit[2,],"[[","BMOUr"),stationary)),dim=c(9,dim(fit)[2])),1,sd)

###
# Get important parameters for the paper

# OUM parameters
(OUM.multi.par <- data.frame(parameters=c("theta_hum","theta_mix","sigma","halftime","stationary"),
                            PC1=c(paste(round(theta_h.m[6,1],3)," [",round(theta_h.50[1,1],3),",",round(theta_h.50[2,1],3),"]",sep=""),
                                  paste(round(theta_g.m[6,1],3)," [",round(theta_g.50[1,1],3),",",round(theta_g.50[2,1],3),"]",sep=""),
                                  paste(round(sigma_h.m[6,1],3)," [",round(sigma_h.50[1,1],3),",",round(sigma_h.50[2,1],3),"]",sep=""),
                                  paste(round(halftime_h.m[6,1],3)," [",round(halftime_h.50[1,1],3),",",round(halftime_h.50[2,1],3),"]",sep=""),
                                  paste(round(station_h.m[6,1],3)," [",round(station_h.50[1,1],3),",",round(station_h.50[2,1],3),"]",sep="")),
                            PC2=c(paste(round(theta_h.m[6,2],3)," [",round(theta_h.50[1,2],3),",",round(theta_h.50[2,2],3),"]",sep=""),
                                  paste(round(theta_g.m[6,2],3)," [",round(theta_g.50[1,2],3),",",round(theta_g.50[2,2],3),"]",sep=""),
                                  paste(round(sigma_h.m[6,5],3)," [",round(sigma_h.50[1,2],3),",",round(sigma_h.50[2,2],3),"]",sep=""),
                                  paste(round(halftime_h.m[6,2],3)," [",round(halftime_h.50[1,2],3),",",round(halftime_h.50[2,2],3),"]",sep=""),
                                  paste(round(station_h.m[6,5],3)," [",round(station_h.50[1,2],3),",",round(station_h.50[2,2],3),"]",sep="")),
                            PC3=c(paste(round(theta_h.m[6,3],3)," [",round(theta_h.50[1,3],3),",",round(theta_h.50[2,3],3),"]",sep=""),
                                  paste(round(theta_g.m[6,3],3)," [",round(theta_g.50[1,3],3),",",round(theta_g.50[2,3],3),"]",sep=""),
                                  paste(round(sigma_h.m[6,9],3)," [",round(sigma_h.50[1,3],3),",",round(sigma_h.50[2,3],3),"]",sep=""),
                                  paste(round(halftime_h.m[6,3],3)," [",round(halftime_h.50[1,3],3),",",round(halftime_h.50[2,3],3),"]",sep=""),
                                  paste(round(station_h.m[6,9],3)," [",round(station_h.50[1,3],3),",",round(station_h.50[2,3],3),"]",sep=""))) )


xtable(OUM.multi.par)

# BMVm sigma
# hum
(sigma_h.BMVm.50 <- apply(apply(array(unlist(sapply(fit[2,],"[[","BMMnc")["sigma",]),dim=c(18,dim(fit)[2]))[1:9,],2,function(c) c(cov2cor(matrix(c,ncol=3,nrow=3)))),1,function(c) quantile(c,probs=c(0.25,0.75))) )
(sigma_h.BMVm.m <- apply(apply(array(unlist(sapply(fit[2,],"[[","BMMnc")["sigma",]),dim=c(18,dim(fit)[2]))[1:9,],2,function(c) c(cov2cor(matrix(c,ncol=3,nrow=3)))),1,median))
# gen
(sigma_g.BMVm.50 <- apply(apply(array(unlist(sapply(fit[2,],"[[","BMMnc")["sigma",]),dim=c(18,dim(fit)[2]))[10:18,],2,function(c) c(cov2cor(matrix(c,ncol=3,nrow=3)))),1,function(c) quantile(c,probs=c(0.25,0.75))) )
(sigma_g.BMVm.m <- apply(apply(array(unlist(sapply(fit[2,],"[[","BMMnc")["sigma",]),dim=c(18,dim(fit)[2]))[10:18,],2,function(c) c(cov2cor(matrix(c,ncol=3,nrow=3)))),1,median))

    
# rates and correlation on simulated data
nsim=100
hum.sim.rate <- matrix(ncol=3,nrow=nsim)
mix.sim.rate <- matrix(ncol=3,nrow=nsim)
hum.sim.cor <- matrix(ncol=9,nrow=nsim)
mix.sim.cor <- matrix(ncol=9,nrow=nsim)
for (sim in 1:nsim){
  simdata <- mvSIM(tree=chartrees[[sim]],nsim=1,model="OUM",param=list(ntraits=3,sigma=fit[2,][[sim]]$OUM$sigma,alpha=fit[2,][[sim]]$OUM$alpha,theta=fit[2,][[sim]]$OUM$theta))
  fit1 <- mvBM(chartrees[[sim]], simdata, model="BMM", 
                method="sparse", param=list(smean=FALSE), 
                scale.height=TRUE, diagnostic=FALSE, echo=FALSE)
  hum.sim.rate[sim,]<-diag(fit1$sigma[,,1])
  mix.sim.rate[sim,]<-diag(fit1$sigma[,,2])
  hum.sim.cor[sim,]<-c(cov2cor(fit1$sigma[,,1]))
  mix.sim.cor[sim,]<-c(cov2cor(fit1$sigma[,,2]))
}
apply(hum.sim.rate,2,median)
apply(mix.sim.rate,2,median)
# Correlations
matrix(apply(hum.sim.cor,2,median),ncol=3,nrow=3)
matrix(apply(mix.sim.cor,2,median),ncol=3,nrow=3)
# correlation quantiles
apply(hum.sim.cor,2,function(c) quantile(c,probs=c(0.25,0.75)))
apply(mix.sim.cor,2,function(c) quantile(c,probs=c(0.25,0.75)))

res.sims <- data.frame(correlations=c(sigma_h.BMVm.m[c(2,3,6)],sigma_g.BMVm.m[c(2,3,6)],apply(hum.sim.cor,2,median)[c(2,3,6)],apply(mix.sim.cor,2,median)[c(2,3,6)]),
                       lowerCI=c(sigma_h.BMVm.50[1,c(2,3,6)],sigma_g.BMVm.50[1,c(2,3,6)],
                               apply(hum.sim.cor,2,function(c) quantile(c,probs=c(0.25,0.75)))[1,c(2,3,6)],
                               apply(mix.sim.cor,2,function(c) quantile(c,probs=c(0.25,0.75)))[1,c(2,3,6)]),
                       upperCI=c(sigma_h.BMVm.50[2,c(2,3,6)],sigma_g.BMVm.50[2,c(2,3,6)],
                                apply(hum.sim.cor,2,function(c) quantile(c,probs=c(0.25,0.75)))[2,c(2,3,6)],
                               apply(mix.sim.cor,2,function(c) quantile(c,probs=c(0.25,0.75)))[2,c(2,3,6)]),
                       comparison=c("PC1 vs. PC2","PC1 vs. PC3","PC2 vs. PC3"),
                       pollination=rep(c("hummingbird","mixed-pollination"),each=3),
                       datatype=factor(rep(c("Observed data","Simulated data"),each=6),levels=c("Observed data","Simulated data")))

pdf(file="cors.sim.allsp.pdf",height = 3.5,width=7)
ggplot(res.sims, aes(y=correlations, x=comparison, group=pollination)) + 
  geom_point(aes(shape=pollination, colour=pollination, fill=pollination), position= position_dodge(width = 0.4), size=2) +
  geom_linerange(aes(ymin=lowerCI, ymax=upperCI, colour=pollination), position= position_dodge(width = 0.4),show.legend = F) + 
  #scale_x_discrete(limits = rev(levels(results.fixed$effects)[-1])) +
  scale_shape_manual(values = c(21,22)) +
  facet_wrap(~datatype) +
  scale_colour_manual(values = c("#d95f02","#7570b3")) +
  scale_fill_manual(values = c("#d95f02","#7570b3")) +
  ylab("Phenotypic correlation") + 
  xlab("Principal components compared") + theme_light() +
  theme(strip.background=element_rect(fill="gray85"), strip.text=element_text(size=10,colour="black"),
        axis.text.x = element_text(angle = 45, vjust = 1, hjust=1))
dev.off()

# end --------------------
