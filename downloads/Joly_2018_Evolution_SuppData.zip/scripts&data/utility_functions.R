
### Read NTS files in R
#
# file: File name with full path
#
# The object returned is a list of two elements:
# 1. spnam: A vector with the name of the images
# 2. landmarks: a 3D array

read.nts <- function(file) {
  job <- scan(file,what="char",quote="",sep="\n",strip.white=T
              , comment.char="\"", quiet=T)
  header <- unlist(strsplit(job[1]," "))
  if (header[1]!=1) {
    stop("There is a problem with the file format")
  }
  if (header[4]!=0) {
    stop("There is a problem with the file format")
  }
  if (length(header)>4) {
    dimp <- grep("DIM=",header)
    if (length(dimp)!=1) {
      stop("There is a problem with file dimensions")
    } else {
      ndim <- as.numeric(unlist(strsplit(header[dimp],"="))[2])
    }
  } else {
    ndim <- 2
  }
  nsp <- as.numeric(unlist(strsplit(header[2],"L")[1]))
  nl <- as.numeric(header[3])/ndim
  job2 <- as.character(unlist(strsplit(job[-1], " ")))
  rownam <- as.character(job2[1:nsp])
  if (length(grep("X",job2))==0) {
    landmarks <- as.numeric(job2[nsp+1:length(job2)])
  } else {
    landmarks <- as.numeric(job2[(nsp+nl*ndim+1):length(job2)])
  }
  data.arr <- aperm(array(landmarks[1:(nsp*ndim*nl)],dim=c(ndim,nl,nsp))
                    , c(2,1,3))
  tps.data <- list(spname=rownam,landmarks=data.arr)
  return(tps.data)
  }


# tps1
#
# modified from the geomorph package

tps1<-function(matr, matt, n,sz=1.5, pt.bg="black",
              grid.col="black", grid.lwd=1, grid.lty=1, refpts=FALSE){  	#DCA: altered from J. Claude: 2D only	
  xm<-min(matt[,1])
  ym<-min(matt[,2])
  xM<-max(matt[,1])
  yM<-max(matt[,2])
  rX<-xM-xm; rY<-yM-ym
  a<-seq(xm-1/5*rX, xM+1/5*rX, length=n)
  b<-seq(ym-1/5*rX, yM+1/5*rX,by=(xM-xm)*7/(5*(n-1)))
  m<-round(0.5+(n-1)*(2/5*rX+ yM-ym)/(2/5*rX+ xM-xm))
  M<-as.matrix(expand.grid(a,b))
  ngrid<-tps2d(M,matr,matt)
  plot(ngrid, cex=0.2,asp=1,axes=FALSE,xlab="",ylab="",type="n")
  for (i in 1:m){lines(ngrid[(1:n)+(i-1)*n,], col=grid.col,lwd=grid.lwd,lty=grid.lty)}
  for (i in 1:n){lines(ngrid[(1:m)*n-i+1,], col=grid.col,lwd=grid.lwd,lty=grid.lty)}
  if(refpts==FALSE) points(matt,pch=21,bg=pt.bg,cex=sz) else points(matr,pch=21,bg=pt.bg,cex=sz)
}

# tps2d
#
#
tps2d<-function(M, matr, matt)
{p<-dim(matr)[1]; q<-dim(M)[1]; n1<-p+3
 P<-matrix(NA, p, p)
 for (i in 1:p)
 {for (j in 1:p){
   r2<-sum((matr[i,]-matr[j,])^2)
   P[i,j]<- r2*log(r2)}}
 P[which(is.na(P))]<-0
 Q<-cbind(1, matr)
 L<-rbind(cbind(P,Q), cbind(t(Q),matrix(0,3,3)))
 m2<-rbind(matt, matrix(0, 3, 2))
 coefx<-fast.solve(L)%*%m2[,1]
 coefy<-fast.solve(L)%*%m2[,2]
 fx<-function(matr, M, coef)
 {Xn<-numeric(q)
  for (i in 1:q)
  {Z<-apply((matr-matrix(M[i,],p,2,byrow=TRUE))^2,1,sum)
   Xn[i]<-coef[p+1]+coef[p+2]*M[i,1]+coef[p+3]*M[i,2]+sum(coef[1:p]*(Z*log(Z)))}
  Xn}
 matg<-matrix(NA, q, 2)
 matg[,1]<-fx(matr, M, coefx)
 matg[,2]<-fx(matr, M, coefy)
 matg}


# fast.ginv
# same as ginv, but without traps (faster)
# used in any function requiring a generalized inverse
fast.ginv <- function(X, tol = sqrt(.Machine$double.eps)){
  k <- ncol(X)
  Xsvd <- La.svd(X, k, k)
  Positive <- Xsvd$d > max(tol * Xsvd$d[1L], 0)
  rtu <-((1/Xsvd$d[Positive]) * t(Xsvd$u[, Positive, drop = FALSE]))
  v <-t(Xsvd$vt)[, Positive, drop = FALSE]
  v%*%rtu
}

# fast.solve
# chooses between fast.ginv or qr.solve, when det might or might not be 0
# used in any function requring a matrix inverse where the certainty of
# singular matrices is in doubt; mostly phylo. functions
fast.solve <- function(x) if(det(x) > 1e-8) qr.solve(x) else fast.ginv(x)

# tangents
# finds tangents in a matrix based on sliders
# used in all functions associated with pPga.wCurvs
tangents = function(s,x, scaled=FALSE){ # s = curves, x = landmarks
  ts <- x[s[,3],] - x[s[,1],]
  if(scaled==TRUE) {
    ts.scale = sqrt(rowSums(ts^2))
    ts <- ts/ts.scale
  }
  y <- matrix(0, nrow(x), ncol(x))
  y[s[,2],] <- ts
  y
}


# Function censored tree

censoredtrees <- function(tree,map,combine.subtrees=TRUE) {
  
  #List of results
  result <- list()
  
  #reorder edge matrix
  tree <- reorder(tree, "postorder")
  map = data.frame(node=map[,1],states=map[,2])
  tips = seq(1,length(tree$tip.label))
  root = as.numeric(seq(length(tree$tip.label)+1,length=tree$Nnode,by=1)[branching.times(tree)==max(branching.times(tree))])
  
  #Loop over syndromes
  for (state in 1:length(levels(map$states))) {
    curstate = levels(map$states)[state]
    #consider tips with good syndrome
    remainningtips = map$node[(map$states == curstate) & (map$node %in% tips)]
    nodeskept <- data.frame(node=numeric(),tip=character())
    #traverse from tips to root to keep monophyletic groups
    for (atip in remainningtips) {
      currentnode <- atip
      nodeproposed <- tree$edge[tree$edge[,2] == atip,1]
      while (map[map$node==nodeproposed,2]==curstate){
        currentnode <- nodeproposed
        nodeproposed <- tree$edge[tree$edge[,2] == currentnode,1]
        if (currentnode == root) break
      }
      # if node kept is a tip, continue
      if(currentnode <= length(tips)) next
      nodeskept <- rbind(nodeskept,data.frame(node=currentnode,tip=tree$tip.label[atip]))
    } # for (atip in remainningtips)
    if(nrow(nodeskept)==0) {
      result[[curstate]] <- NULL
      next
    }
    internalnodeskept <- unique(nodeskept$node)
    internalnodeskept <- internalnodeskept[order(internalnodeskept)]
    # For cases where subtrees are not merged
    if(combine.subtrees==FALSE) {
      censtrees <- list()
      tree.number = 1
    }
    # loops through nodes kept and merge then in phylo
    # First, case when there is only one internal node.
    if (length(internalnodeskept)==1) {
      subtree <- extract.clade(tree,internalnodeskept[1])
      #remove species after reversal
      keep <- nodeskept[nodeskept$node==internalnodeskept[1],2]
      exclude <- subtree$tip.label[!(subtree$tip.label %in% keep)]
      # check if a single tip remains... if so, ignore (would make a tree with one tip)
      if ((length(subtree$tip.label) - length(exclude)) <=2 ) {
        result[[curstate]] <- NULL
        next
      } 
      if(length(exclude)>=1) subtree <- drop.tip(subtree,exclude)
      result[[curstate]] <- subtree
      if(combine.subtrees==FALSE) {
        #exclude species with wrong pollination syndrome
        exclude <- subtree$tip.label[map[match(subtree$tip.label,tree$tip.label),2]!=curstate]
        subtree <- drop.tip(subtree,exclude)
        if(length(subtree$tip.label)<=2) next
        censtrees[[tree.number]] <- subtree
        result[[curstate]] <- censtrees
        tree.number = tree.number+1
      }
      next
    } # if (length(internalnodeskept)==1)
    # If several subtrees exist, combine them
    first=TRUE
    subtree <- NULL
    for (anode in internalnodeskept) {
      if (first) {
        subtree <- extract.clade(tree,anode)
        keep <- nodeskept[nodeskept$node==anode,2]
        #exclude species from good state but after reversal
        potential.keep <- subtree$tip.label[map[match(subtree$tip.label,tree$tip.label),2]==curstate]
        exclude <- potential.keep[!(potential.keep %in% keep)]
        if((length(subtree$tip.label)-length(exclude))<=2) {
          #dropped <- subtree$tip.label[!(subtree$tip.label %in% exclude)]
          #warning("species ",dropped," dropped from tree",immediate.=TRUE)
          next
        }
        if(length(exclude)>0) subtree <- drop.tip(subtree,exclude)
        if(combine.subtrees==FALSE) {
          #exclude species with wrong pollination syndrome
          exclude <- subtree$tip.label[map[match(subtree$tip.label,tree$tip.label),2]!=curstate]
          subtree <- drop.tip(subtree,exclude)
          if(length(subtree$tip.label)<=2) next
          censtrees[[tree.number]] <- subtree
          tree.number = tree.number+1
        }
        first=FALSE
        next
      }
      subtree2 <- extract.clade(tree,anode)
      keep <- nodeskept[nodeskept$node==anode,2]
      #exclude species from good state but after reversal
      potential.keep <- subtree2$tip.label[map[match(subtree2$tip.label,tree$tip.label),2]==curstate]
      exclude <- potential.keep[!(potential.keep %in% keep)]
      if((length(subtree2$tip.label)-length(exclude))<=2) next
      if(length(exclude)>0) subtree2 <- drop.tip(subtree2,exclude)
      #Combine with first subtree
      subtree <- bind.tree(subtree,subtree2)
      if(combine.subtrees==FALSE) {
        #exclude species with wrong pollination syndrome
        exclude <- subtree2$tip.label[map[match(subtree2$tip.label,tree$tip.label),2]!=curstate]
        subtree2 <- drop.tip(subtree2,exclude)
        if(length(subtree2$tip.label)<=2) next
        censtrees[[tree.number]] <- subtree2        
        tree.number = tree.number+1
      }
    } # for (anode in internalnodeskept)
    if(combine.subtrees==TRUE) {
      #exclude species with wrong pollination syndrome
      exclude <- subtree$tip.label[map[match(subtree$tip.label,tree$tip.label),2]!=curstate]
      subtree <- drop.tip(subtree,exclude)
      result[[curstate]] <- subtree
    }
    if(combine.subtrees==FALSE) {
      result[[curstate]] <- censtrees
    }
  } # for (state in 1:length(levels(map$states)))
  return(result)
}
